# Sequencing depth and tissue composition confound lactylation–mitophagy coupling in osteosarcoma

This repository contains the analysis code and derived summary tables for a multi-scale reanalysis of public osteosarcoma bulk, single-cell and spatial transcriptomes.

## What the study asks

Composite lactylation and mitophagy scores have been used to infer coupling between the two programs. We tested whether this coupling survives:

- sequencing-depth control;
- tissue-composition adjustment;
- expression-matched random gene-set nulls;
- bulk clinical endpoints with FDR correction.

The main finding is that strong raw correlations are largely explained by library complexity and tissue composition. A small residual association remains in some datasets, but it is not consistent and does not support a strong coupling or biomarker claim.

## Repository contents

| Directory | Contents |
|---|---|
| `scripts/` | Analysis scripts used for single-cell, spatial, bulk and null-model analyses |
| `derived_tables/` | Summary tables used for figures and supplementary tables |
| `figures/` | Main figures, PDF |
| `supplementary/` | Additional files 1–3 |
| `data/` | Data-access instructions and expected local layout (raw data not included) |
| `docs/` | Workflow, data sources, reproducibility and manifest |

## Data

Raw data are public and are not redistributed here. Accessions:

- Bulk: TARGET-OS (GDC), GSE21257, GSE39055, GSE33382, GSE16091
- Single-cell: GSE152048, GSE162454, GSE318840
- Spatial: GSE299025

See `data/README.md` for accessions, platforms and the expected local directory layout.

## Environment

- Python 3.11+
- numpy, pandas, scipy, matplotlib, scikit-learn, statsmodels
- R 4.6.1 with the `survival` package for Cox models

Install Python dependencies:

```bash
pip install -r requirements.txt
```

## Path configuration

The archived scripts use three environment variables:

```bash
OSLM_DATA_ROOT=/path/to/data
OSLM_WORK_ROOT=/path/to/work
OSLM_OUTPUT_ROOT=/path/to/outputs
```

If unset, they default to `data/`, `work/` and `outputs/` relative to the repository root.

Expected layout:

```text
data/
  A2/                 # single-cell/spatial inputs used by the scripts
  bulk_processed/     # TARGET/GEO matrices and metadata
  genesets/           # curated lactylation and mitophagy gene sets
work/
  week1/
  week2/
  week3/
outputs/
  week1/
  week2/
  week3/
```

## Run order

1. `scripts/week1_scoring.py`
2. `scripts/week1_spatial.py`
3. `scripts/week1_figures.py`
4. `scripts/week2_signatures.py`
5. `scripts/week2_spatial.py`
6. `scripts/week2_bulk_scores.py`
7. `scripts/week2_survival.R` (run from `work/week2`)
8. `scripts/week2_figures.py`
9. `scripts/week3_null_model.py`
10. `scripts/week3_figures.py`

See `docs/analysis_workflow.md` and `docs/reproducibility.md` for details.

## Citation

If you use this code or derived tables, please cite the manuscript:

> Guo S, Ren Z. Sequencing depth and tissue composition confound lactylation–mitophagy coupling in osteosarcoma: a multi-scale reanalysis. 2026.

## License

Code: MIT License. Derived tables and figures: CC BY 4.0, subject to the licenses of the source datasets.
