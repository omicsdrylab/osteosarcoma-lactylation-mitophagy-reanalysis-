# Data access

Raw data are not included in this repository.

## Bulk cohorts

| Dataset | Accession | Platform | Use |
|---|---|---|---|
| TARGET-OS | GDC / TARGET | RNA-seq | EFS and OS |
| GSE21257 | GEO | Illumina Human-6 v2.0 | Metastasis |
| GSE39055 | GEO | Illumina HumanHT-12 | Recurrence and OS |
| GSE33382 | GEO | Illumina Human-6 v2.0 | Metastasis within 5 years |
| GSE16091 | GEO | Affymetrix HG-U133A | OS |

## Single-cell datasets

- GSE152048: BC2 and BC3 used in this reanalysis.
- GSE162454: OS_4 used in this reanalysis.
- GSE318840: Treated1 and Recurrent1 used in this reanalysis.

## Spatial dataset

- GSE299025: PatientA and PatientB (10x Visium).

## Expected local layout

The scripts expect 10x matrices under:

```text
data/A2/incoming/GSE152048/BC2/
data/A2/incoming/GSE152048/BC3/
data/A2/incoming/GSE162454/OS_4/
data/A2/incoming/GSE318840/Treated1/
data/A2/incoming/GSE318840/Recurrent1/
data/A2/incoming/GSE299025/PatientA/
data/A2/incoming/GSE299025/PatientB/
```

Bulk matrices and metadata are expected under `data/bulk_processed/`.

Gene sets are under `data/genesets/`.

To make the spatial correlation script immediately testable, the repository also includes:

- `data/A2/A2_week8_spatial_spot_scores.tsv.gz` (derived per-spot scores)
- `data/genesets/lactylation_genes_v1.tsv`
- `data/genesets/mitophagy_genes_v1.tsv`
