# Analysis workflow

## Week 1: scoring and depth control

`week1_scoring.py`

- Build raw z-mean, AddModuleScore-like and UCell-like scores.
- Downsample counts by binomial thinning within each sample.
- Decompose the lactylation program into supply, writers, erasers and readers.

`week1_spatial.py`

- Compute spot-level partial Spearman correlations.
- Use 8×8 spatial tiles for block bootstrap confidence intervals.

`week1_figures.py`

- Figure 1: score construction and depth diagnostics.
- Figure 2: lactylation submodule decomposition.
- Figure 3: composition-adjusted spatial associations using the original scores.

## Week 2: spatial deconvolution and bulk clinical models

`week2_signatures.py`

- Build single-cell pseudobulk signatures.
- Note: the state-specific high/low signature was exploratory and was not used for inference.

`week2_spatial.py`

- NNLS deconvolution attempt with curated markers.
- Validation against marker scores.
- Association tests in malignant-high and myeloid-high spots.

`week2_bulk_scores.py`

- Score bulk cohorts for L, M, supply, writers, erasers, readers, HDAC6–SQSTM1, glycolysis and L×M.
- Merge clinical endpoints.

`week2_survival.R`

- Cox models with `survival::coxph`.
- Logistic models with `glm`.
- Benjamini–Hochberg FDR within cohort/endpoint/model.

`week2_figures.py`

- Figure 4: spatial score sensitivity.
- Figure 5: bulk clinical associations.

## Week 3: null models and reporting

`week3_null_model.py`

- Generate 1,000 expression/detection-matched random gene sets.
- Compare observed L–M correlations with the null.

`week3_figures.py`

- Figure 1: study design.
- Figure 6: reporting checklist.
