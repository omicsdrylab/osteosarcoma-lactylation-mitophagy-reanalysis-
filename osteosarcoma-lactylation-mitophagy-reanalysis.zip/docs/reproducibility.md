# Reproducibility notes

## Python

Create a clean environment and install:

```bash
pip install -r requirements.txt
```

## R

Cox and logistic models use R 4.6.1 and the base `survival` package.

Run from `work/week2/`:

```bash
Rscript ../../scripts/week2_survival.R
```

The script reads `bulk_scores_clinical.tsv` and writes `bulk_survival_results.tsv`.

## Paths

Set:

```bash
export OSLM_DATA_ROOT=/path/to/data
export OSLM_WORK_ROOT=/path/to/work
export OSLM_OUTPUT_ROOT=/path/to/outputs
```

On Windows PowerShell:

```powershell
$env:OSLM_DATA_ROOT="C:\path\to\data"
$env:OSLM_WORK_ROOT="C:\path\to\work"
$env:OSLM_OUTPUT_ROOT="C:\path\to\outputs"
```

## Notes

- The scripts are the exact analysis code used for the manuscript, with path constants replaced by environment variables.
- Seeded random procedures (gene-set nulls and bootstrap) use fixed seeds in the scripts.
- Raw data are not redistributed; download them from GEO/GDC.
- The NNLS deconvolution was exploratory and unstable; the manuscript reports it as a limitation, not as a biological result.
