# Scripts

| Script | Purpose |
|---|---|
| `week1_scoring.py` | Rebuild single-cell L/M scores and depth controls |
| `week1_spatial.py` | Spatial partial correlations and block bootstrap |
| `week1_figures.py` | Figures 1–2 |
| `week2_signatures.py` | Single-cell pseudobulk signatures |
| `week2_spatial.py` | Spatial deconvolution attempt and marker analysis |
| `week2_bulk_scores.py` | Bulk program scores and clinical merge |
| `week2_survival.R` | Cox and logistic models |
| `week2_figures.py` | Figures 4–5 |
| `week3_null_model.py` | Expression-matched random gene-set nulls |
| `week3_figures.py` | Figure 1 and Figure 6 |

See `../docs/analysis_workflow.md` for run order.
