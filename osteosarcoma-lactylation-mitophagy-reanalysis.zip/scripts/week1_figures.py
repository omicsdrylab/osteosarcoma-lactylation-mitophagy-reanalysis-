"""Week 1 figures: scoring/depth diagnostics, module decomposition, spatial CIs."""

from __future__ import annotations

import os

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyBboxPatch
from scipy import stats

mpl.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 7.5,
        "axes.titlesize": 8.5,
        "axes.labelsize": 7.5,
        "xtick.labelsize": 7,
        "ytick.labelsize": 7,
        "legend.fontsize": 7,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.dpi": 400,
    }
)

ROOT = os.path.join(os.environ.get("OSLM_WORK_ROOT", "work"), "week1")
OUT = os.path.join(os.environ.get("OSLM_OUTPUT_ROOT", "outputs"), "week1")
os.makedirs(OUT, exist_ok=True)

SAMPLE_LABEL = {
    "GSE152048_BC2": "BC2",
    "GSE152048_BC3": "BC3",
    "GSE162454_OS4": "OS4",
    "GSE318840_Treated1": "Treated1",
    "GSE318840_Recurrent1": "Recurrent1",
}
SAMPLE_ORDER = list(SAMPLE_LABEL)
COL = {
    "zmean_raw": "#9E9E9E",
    "add_raw": "#DD8452",
    "add_down": "#4C72B0",
    "ucell_raw": "#C44E52",
    "ucell_down": "#55A868",
    "zmean_down": "#8172B3",
}


def save(fig, name):
    fig.savefig(os.path.join(OUT, f"{name}.pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, f"{name}.png"), bbox_inches="tight", dpi=400)
    plt.close(fig)


def schematic(ax):
    ax.set_axis_off()
    boxes = [
        ("1  Bulk cohorts\n4 public datasets", "#E8F0F7"),
        ("2  Single-cell\n5 samples / 3 datasets", "#FDF0E6"),
        ("3  Spatial\n2 Visium samples", "#EAF4EA"),
        ("4  Scoring\nz-mean, AMS, UCell", "#F0EDF7"),
        ("5  Depth control\nbinomial downsampling", "#F7EDED"),
        ("6  Decomposition\nsupply, writers, erasers, readers", "#F2F2F2"),
    ]
    w, h, gx, gy = 0.44, 0.24, 0.04, 0.09
    for i, (text, color) in enumerate(boxes):
        row, col = divmod(i, 2)
        x = 0.03 + col * (w + gx)
        y = 0.74 - row * (h + gy)
        ax.add_patch(
            FancyBboxPatch(
                (x, y),
                w,
                h,
                boxstyle="round,pad=0.012,rounding_size=0.02",
                linewidth=0.8,
                edgecolor="#555555",
                facecolor=color,
                transform=ax.transAxes,
                clip_on=False,
            )
        )
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=7.0, transform=ax.transAxes)
    ax.text(0.005, 1.02, "a", fontsize=11, fontweight="bold", transform=ax.transAxes, clip_on=False)
    ax.text(0.03, -0.06, "Week 1: rebuild scores, remove depth effects, decompose the lactylation program", fontsize=6.6, color="#444444", transform=ax.transAxes, clip_on=False)


def fig1():
    corr = pd.read_csv(os.path.join(ROOT, "correlation_summary.tsv"), sep="\t")
    pc = {s: pd.read_csv(os.path.join(ROOT, f"percell_{s}.tsv.gz"), sep="\t") for s in SAMPLE_ORDER}

    fig = plt.figure(figsize=(7.2, 7.6))
    gs = fig.add_gridspec(3, 2, height_ratios=[0.62, 1.0, 1.0], hspace=0.52, wspace=0.34)
    ax0 = fig.add_subplot(gs[0, :])
    schematic(ax0)

    # b: depth by cell type
    axb = fig.add_subplot(gs[1, 0])
    xs, labels = [], []
    pos = 0
    for s in SAMPLE_ORDER:
        d = pc[s]
        for ct, color in [("Malignant_Osteoblastic", "#C44E52"), ("Myeloid", "#4C72B0")]:
            v = d.loc[d["cell_type"] == ct, "n_genes"].dropna()
            if len(v) < 30:
                continue
            bp = axb.boxplot(
                [v],
                positions=[pos],
                widths=0.65,
                patch_artist=True,
                showfliers=False,
                medianprops=dict(color="black", lw=0.8),
                boxprops=dict(facecolor=color, alpha=0.7, lw=0.5),
                whiskerprops=dict(lw=0.5),
                capprops=dict(lw=0.5),
            )
            pos += 1
        xs.append(pos - 1)
        labels.append(SAMPLE_LABEL[s])
        pos += 0.6
    axb.set_yscale("log")
    axb.set_ylabel("Genes detected per cell")
    axb.set_xticks([x - 0.3 for x in xs])
    axb.set_xticklabels(labels, rotation=30, ha="right")
    axb.set_title("Depth: malignant (red) vs myeloid (blue)", fontsize=8)
    axb.text(-0.18, 1.02, "b", transform=axb.transAxes, fontsize=11, fontweight="bold")

    # c: heatmap of rho by method and sample, both cell types
    methods = ["zmean_raw", "add_raw", "add_down"]
    method_labels = ["z-mean\nraw", "AddModule\nraw", "AddModule\ndownsampled"]
    axc = fig.add_subplot(gs[1, 1])
    row_labels = ["Mal. z-mean", "Mal. AMS raw", "Mal. AMS down",
                  "Mye. z-mean", "Mye. AMS raw", "Mye. AMS down"]
    mat = np.full((6, len(SAMPLE_ORDER)), np.nan)
    for k, ct in enumerate(["Malignant_Osteoblastic", "Myeloid"]):
        d = corr[(corr["cell_type"] == ct) & (corr["method"].isin(methods))]
        for i, m in enumerate(methods):
            for j, s in enumerate(SAMPLE_ORDER):
                v = d[(d["method"] == m) & (d["sample"] == s)]["rho"]
                if len(v):
                    mat[k * 3 + i, j] = float(v.iloc[0])
    im = axc.imshow(mat, cmap="RdBu_r", vmin=-0.15, vmax=0.6, aspect="auto")
    axc.set_xticks(range(len(SAMPLE_ORDER)))
    axc.set_xticklabels([SAMPLE_LABEL[s] for s in SAMPLE_ORDER], rotation=35, ha="right")
    axc.set_yticks(range(6))
    axc.set_yticklabels(row_labels)
    for i in range(6):
        for j in range(len(SAMPLE_ORDER)):
            if np.isfinite(mat[i, j]):
                axc.text(j, i, f"{mat[i, j]:.2f}", ha="center", va="center", fontsize=6.4, color="black")
            else:
                axc.text(j, i, "n/a", ha="center", va="center", fontsize=5.8, color="#777777")
    axc.set_title("L–M correlation by scoring method")
    axc.text(-0.28, 1.08, "c", transform=axc.transAxes, fontsize=11, fontweight="bold")
    cbar = fig.colorbar(im, ax=axc, fraction=0.030, pad=0.02)
    cbar.set_label("Spearman ρ (L vs M)")

    # d: two scatters side by side
    subgs = gs[2, :].subgridspec(1, 2, wspace=0.30)
    handles = []
    for k, s in enumerate(["GSE152048_BC2", "GSE162454_OS4"]):
        axd = fig.add_subplot(subgs[0, k])
        d = pc[s]
        for ct, color, lab in [("Malignant_Osteoblastic", "#C44E52", "Malignant"), ("Myeloid", "#4C72B0", "Myeloid")]:
            sub = d[d["cell_type"] == ct].dropna(subset=["L_down_add", "M_down_add"])
            if len(sub) < 30:
                continue
            h = axd.scatter(sub["L_down_add"], sub["M_down_add"], s=4, alpha=0.28, color=color, linewidth=0, label=lab)
            if k == 0:
                handles.append(h)
            r = stats.spearmanr(sub["L_down_add"], sub["M_down_add"]).statistic
            axd.text(0.03, 0.94 - 0.09 * (ct == "Myeloid"), f"{lab}: ρ={r:.2f}", transform=axd.transAxes, fontsize=6.6, color=color)
        axd.set_xlabel("L score (AddModuleScore, downsampled)")
        if k == 0:
            axd.set_ylabel("M score")
            axd.legend(frameon=False, markerscale=2, loc="upper right")
        axd.set_title(f"{SAMPLE_LABEL[s]}: depth-equalized scores")
        if k == 0:
            axd.text(-0.20, 1.05, "d", transform=axd.transAxes, fontsize=11, fontweight="bold")

    fig.text(0.01, 0.005, "AMS = AddModuleScore. Downsampled = binomial thinning to 1,000 UMIs (OS4: 2,000; Treated1: 400).", fontsize=6.2, color="#555555")
    save(fig, "Figure1_week1_scoring_depth")


def random_effects(sub: pd.DataFrame, rcol="rho_M", ncol="n"):
    z = np.arctanh(np.clip(sub[rcol].to_numpy(float), -0.999999, 0.999999))
    v = 1.0 / (sub[ncol].to_numpy(float) - 3)
    w = 1.0 / v
    zfe = np.sum(w * z) / np.sum(w)
    Q = np.sum(w * (z - zfe) ** 2)
    dfree = len(z) - 1
    C = np.sum(w) - np.sum(w**2) / np.sum(w)
    tau2 = max(0.0, (Q - dfree) / C) if dfree > 0 and C > 0 else 0.0
    wr = 1.0 / (v + tau2)
    zre = np.sum(wr * z) / np.sum(wr)
    se = np.sqrt(1.0 / np.sum(wr))
    return np.tanh(zre), np.tanh(zre - 1.96 * se), np.tanh(zre + 1.96 * se)


def fig2():
    mod = pd.read_csv(os.path.join(ROOT, "module_summary.tsv"), sep="\t")
    modules = ["supply", "writers", "erasers", "readers"]
    mod_labels = ["Lactate supply", "Writers", "Erasers", "Readers"]
    d = mod[(mod["cell_type"] == "Malignant_Osteoblastic") & (mod["scale"] == "downsampled")]

    fig = plt.figure(figsize=(7.2, 6.2))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.1, 1.0], hspace=0.45, wspace=0.34)

    axa = fig.add_subplot(gs[0, 0])
    mat = np.full((len(modules), len(SAMPLE_ORDER)), np.nan)
    for i, m in enumerate(modules):
        for j, s in enumerate(SAMPLE_ORDER):
            v = d[(d["module"] == m) & (d["sample"] == s)]["rho_M"]
            if len(v):
                mat[i, j] = float(v.iloc[0])
    im = axa.imshow(mat, cmap="RdBu_r", vmin=-0.15, vmax=0.35, aspect="auto")
    axa.set_xticks(range(len(SAMPLE_ORDER)))
    axa.set_xticklabels([SAMPLE_LABEL[s] for s in SAMPLE_ORDER], rotation=35, ha="right")
    axa.set_yticks(range(len(modules)))
    axa.set_yticklabels(mod_labels)
    for i in range(len(modules)):
        for j in range(len(SAMPLE_ORDER)):
            if np.isfinite(mat[i, j]):
                axa.text(j, i, f"{mat[i, j]:.2f}", ha="center", va="center", fontsize=6.6)
    axa.set_title("Submodule vs mitophagy (malignant)")
    axa.text(-0.30, 1.10, "a", transform=axa.transAxes, fontsize=11, fontweight="bold")

    # b: pooled module correlations
    axb = fig.add_subplot(gs[0, 1])
    ys = np.arange(len(modules))
    for i, m in enumerate(modules):
        sub = d[d["module"] == m]
        r, lo, hi = random_effects(sub)
        axb.errorbar(r, i, xerr=[[r - lo], [hi - r]], fmt="o", color="#333333", ms=4, lw=1)
        jitter = np.random.default_rng(3).uniform(-0.10, 0.10, len(sub))
        axb.scatter(sub["rho_M"], np.full(len(sub), i) + jitter, s=9, color="#4C72B0", alpha=0.7, linewidth=0)
    axb.axvline(0, color="#999999", lw=0.7, ls="--")
    axb.set_yticks(ys)
    axb.set_yticklabels(mod_labels)
    axb.invert_yaxis()
    axb.set_xlabel("Spearman ρ with M (downsampled)")
    axb.set_title("Pooled across 5 samples")
    axb.text(-0.22, 1.10, "b", transform=axb.transAxes, fontsize=11, fontweight="bold")

    # c: submodule correlation matrix in OS4
    axc = fig.add_subplot(gs[1, 0])
    p = pd.read_csv(os.path.join(ROOT, "percell_GSE162454_OS4.tsv.gz"), sep="\t")
    p = p[p["cell_type"] == "Malignant_Osteoblastic"]
    cols = [f"{m}_down_add" for m in modules] + ["M_down_add"]
    labels = mod_labels + ["Mitophagy"]
    cm = p[cols].corr(method="spearman").to_numpy()
    im2 = axc.imshow(cm, cmap="RdBu_r", vmin=-0.4, vmax=0.6)
    axc.set_xticks(range(len(labels)))
    axc.set_xticklabels(labels, rotation=35, ha="right")
    axc.set_yticks(range(len(labels)))
    axc.set_yticklabels(labels)
    for i in range(len(labels)):
        for j in range(len(labels)):
            axc.text(j, i, f"{cm[i, j]:.2f}", ha="center", va="center", fontsize=6.2)
    axc.set_title("OS4: submodule co-expression")
    axc.text(-0.32, 1.10, "c", transform=axc.transAxes, fontsize=11, fontweight="bold")

    # d: net potential vs M in OS4 and BC3
    axd = fig.add_subplot(gs[1, 1])
    for s, color, marker in [("GSE162454_OS4", "#C44E52", "o"), ("GSE152048_BC3", "#4C72B0", "s")]:
        p = pd.read_csv(os.path.join(ROOT, f"percell_{s}.tsv.gz"), sep="\t")
        p = p[p["cell_type"] == "Malignant_Osteoblastic"].copy()
        z = lambda c: (p[c] - p[c].mean()) / p[c].std(ddof=0)
        net = z("supply_down_add") + z("writers_down_add") - z("erasers_down_add")
        r = stats.spearmanr(net, p["M_down_add"]).statistic
        axd.scatter(net, p["M_down_add"], s=4, alpha=0.25, color=color, linewidth=0, label=f"{SAMPLE_LABEL[s]} (ρ={r:.2f})")
    axd.axhline(0, color="#999999", lw=0.5)
    axd.axvline(0, color="#999999", lw=0.5)
    axd.set_xlabel("Net lactylation potential\n(supply + writers − erasers)")
    axd.set_ylabel("M score (downsampled)")
    axd.set_title("Net potential vs mitophagy")
    axd.legend(frameon=False, markerscale=2, loc="upper left")
    axd.text(-0.22, 1.10, "d", transform=axd.transAxes, fontsize=11, fontweight="bold")

    save(fig, "Figure2_week1_module_decomposition")


def fig3():
    sp = pd.read_csv(os.path.join(ROOT, "spatial_partial_bootstrap.tsv"), sep="\t")
    scores = pd.read_csv(r"C:\Users\常昆\Documents\Codex\2026-10-02\w\work\A2\A2_week8_spatial_spot_scores.tsv.gz", sep="\t")
    pos = {
        "PatientA": r"C:\Users\常昆\Documents\Codex\2026-10-02\w\work\A2\incoming\GSE299025\PatientA\tissue_positions_list.csv.gz",
        "PatientB": r"C:\Users\常昆\Documents\Codex\2026-10-02\w\work\A2\incoming\GSE299025\PatientB\tissue_positions_list.csv.gz",
    }
    cols = ["barcode", "in_tissue", "array_row", "array_col", "pxl_row", "pxl_col"]

    fig = plt.figure(figsize=(7.2, 6.9))
    gs = fig.add_gridspec(3, 3, height_ratios=[1.0, 1.0, 1.15], hspace=0.18, wspace=0.22)

    for r, s in enumerate(["PatientA", "PatientB"]):
        d = scores[scores["sample"] == s].merge(pd.read_csv(pos[s], header=None, names=cols), on="barcode")
        for c, (score, label) in enumerate(
            [("L_primary", "L program"), ("M_primary", "M program"), ("HDAC6_SQSTM1", "HDAC6–SQSTM1")]
        ):
            ax = fig.add_subplot(gs[r, c])
            v = d[score].to_numpy()
            vmin, vmax = np.percentile(v, [2, 98])
            sc = ax.scatter(d["array_col"], -d["array_row"], c=v, s=4, cmap="viridis", vmin=vmin, vmax=vmax, linewidth=0)
            ax.set_aspect("equal")
            ax.set_xticks([])
            ax.set_yticks([])
            ax.set_title(f"{s}: {label}", fontsize=8)
            if c == 0:
                ax.text(-0.12, 1.08, "a" if r == 0 else "", transform=ax.transAxes, fontsize=11, fontweight="bold")
            cb = fig.colorbar(sc, ax=ax, fraction=0.035, pad=0.01)
            cb.ax.tick_params(labelsize=5.5)

    # forest plot
    axf = fig.add_subplot(gs[2, :2])
    order = [
        "L-M (composition-adjusted)",
        "L-HDAC6_SQSTM1 (M + composition)",
        "M-HDAC6_SQSTM1 (L + composition)",
        "L-M2_TAM (composition)",
        "M-M2_TAM (composition)",
    ]
    short = ["L–M", "L–HDAC6–SQSTM1", "M–HDAC6–SQSTM1", "L–M2/TAM", "M–M2/TAM"]
    ys = np.arange(len(order))
    for k, s in enumerate(["PatientA", "PatientB"]):
        color = "#C44E52" if k == 0 else "#4C72B0"
        for i, lab in enumerate(order):
            row = sp[(sp["sample"] == s) & (sp["pair"] == lab)]
            if len(row) == 0:
                continue
            r = float(row["partial_rho"].iloc[0])
            lo = float(row["ci_low"].iloc[0])
            hi = float(row["ci_high"].iloc[0])
            y = i + (k - 0.5) * 0.22
            axf.errorbar(r, y, xerr=[[r - lo], [hi - r]], fmt="o", color=color, ms=4, lw=1, capsize=1.5, label=s if i == 0 else None)
    axf.axvline(0, color="#999999", lw=0.7, ls="--")
    axf.set_yticks(ys)
    axf.set_yticklabels(short)
    axf.set_xlabel("Partial Spearman ρ (95% block-bootstrap CI)")
    axf.set_title("Composition-adjusted spatial associations\nred: PatientA; blue: PatientB", fontsize=8)
    axf.text(-0.30, 1.10, "b", transform=axf.transAxes, fontsize=11, fontweight="bold")

    # specificity bars
    axs = fig.add_subplot(gs[2, 2])
    pairs = ["L-M (composition-adjusted)", "L-HDAC6_SQSTM1 (M + composition)", "L-M2_TAM (composition)", "L-Myeloid (composition)"]
    labs = ["M", "HDAC6–\nSQSTM1", "M2/TAM", "Myeloid"]
    x = np.arange(len(pairs))
    for k, s in enumerate(["PatientA", "PatientB"]):
        vals = []
        for p in pairs:
            row = sp[(sp["sample"] == s) & (sp["pair"] == p)]
            vals.append(float(row["partial_rho"].iloc[0]) if len(row) else np.nan)
        axs.bar(x + (k - 0.5) * 0.34, vals, width=0.34, color=["#C44E52", "#4C72B0"][k], label=s)
    axs.set_xticks(x)
    axs.set_xticklabels(labs, rotation=30, ha="right")
    axs.set_ylabel("Partial ρ with L")
    axs.set_title("Specificity of L coupling")
    axs.legend(frameon=False, fontsize=6)
    axs.text(-0.35, 1.10, "c", transform=axs.transAxes, fontsize=11, fontweight="bold")

    save(fig, "Figure3_week1_spatial")


if __name__ == "__main__":
    fig1()
    fig2()
    fig3()
    print("saved figures to", OUT)
