"""
Week 1 analysis:
1) Rebuild single-cell L/M scores with three scoring methods:
   - z-mean (original style)
   - AddModuleScore-like (expression-bin matched controls)
   - UCell-like rank score
2) Repeat after binomial downsampling to a common depth within each sample.
3) Decompose the lactylation program into supply / writers / erasers / readers
   and test which submodule tracks mitophagy.

Outputs are written to work/week1/.
"""

from __future__ import annotations

import gzip
import os
import time

import numpy as np
import pandas as pd
import scipy.io
import scipy.sparse as sp
from scipy import stats

ROOT = os.path.join(os.environ.get("OSLM_DATA_ROOT", "data"), "A2")
GENESETS = os.path.join(os.environ.get("OSLM_DATA_ROOT", "data"), "genesets")
OUT = os.path.join(os.environ.get("OSLM_WORK_ROOT", "work"), "week1")
os.makedirs(OUT, exist_ok=True)

SAMPLES = {
    "GSE152048_BC2": ("GSE152048", "BC2", 1000),
    "GSE152048_BC3": ("GSE152048", "BC3", 1000),
    "GSE162454_OS4": ("GSE162454", "OS_4", 2000),
    "GSE318840_Treated1": ("GSE318840", "Treated1", 400),
    "GSE318840_Recurrent1": ("GSE318840", "Recurrent1", 1000),
}

SUBMODULES = {
    "supply": ["LDHA", "LDHB", "SLC16A1", "SLC16A3", "SLC16A7", "PKM", "HK1", "HK2", "PFKFB3", "HIF1A"],
    "writers": ["AARS1", "AARS2", "EP300", "CREBBP", "KAT2A", "KAT5", "KAT8"],
    "erasers": ["HDAC1", "HDAC2", "HDAC3", "HDAC6", "SIRT1", "SIRT2", "SIRT3", "SIRT6"],
    "readers": ["BRD9", "DPF2", "BRD4"],
}


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def load_genesets():
    lac = pd.read_csv(os.path.join(GENESETS, "lactylation_genes_v1.tsv"), sep="\t")
    mito = pd.read_csv(os.path.join(GENESETS, "mitophagy_genes_v1.tsv"), sep="\t")
    L = lac.loc[lac["include_primary"] == 1, "gene"].astype(str).tolist()
    M = mito.loc[mito["include_primary_GO"] == 1, "gene"].astype(str).tolist()
    return L, M


def load_matrix(sample_dir: str):
    features = pd.read_csv(os.path.join(sample_dir, "features.tsv.gz"), sep="\t", header=None)
    barcodes = pd.read_csv(os.path.join(sample_dir, "barcodes.tsv.gz"), sep="\t", header=None)[0].astype(str).to_numpy()
    mat = scipy.io.mmread(os.path.join(sample_dir, "matrix.mtx.gz"))
    mat = sp.csr_matrix(mat)
    symbols = features[1].astype(str).to_numpy()

    # Collapse duplicate gene symbols by summing counts.
    uniq, inv = np.unique(symbols, return_inverse=True)
    agg = sp.csr_matrix(
        (np.ones(len(inv), dtype=np.float32), (inv, np.arange(len(inv)))),
        shape=(len(uniq), len(inv)),
    )
    mat = (agg @ mat).tocsr()
    return mat, uniq, barcodes


def normalize_log(mat: sp.csr_matrix) -> sp.csr_matrix:
    """mat: genes x cells raw counts -> log1p(CP10k) genes x cells CSR."""
    x = mat.T.tocsr().astype(np.float32)
    lib = np.asarray(x.sum(axis=1)).ravel()
    lib[lib == 0] = 1.0
    scale = (1e4 / lib).astype(np.float32)
    x.data *= np.repeat(scale, np.diff(x.indptr))
    x.data = np.log1p(x.data)
    return x


def zmean_score(x: sp.csr_matrix, genes: list[str], gene_index: dict[str, int]) -> np.ndarray:
    idx = [gene_index[g] for g in genes if g in gene_index]
    if len(idx) == 0:
        return np.full(x.shape[0], np.nan)
    sub = x[:, idx].toarray().astype(np.float64)
    mu = sub.mean(axis=0)
    sd = sub.std(axis=0)
    sd[sd == 0] = 1.0
    return ((sub - mu) / sd).mean(axis=1)


def build_control_pool(
    mean_expr: np.ndarray,
    detection: np.ndarray,
    exclude: set[int],
    n_bins: int = 25,
    n_ctrl: int = 50,
    seed: int = 13,
) -> dict[int, np.ndarray]:
    """For each gene index, return a matched control pool (by expression bin)."""
    ok = np.ones(len(mean_expr), dtype=bool)
    ok[list(exclude)] = False
    ok &= np.isfinite(mean_expr)
    bins = pd.qcut(pd.Series(mean_expr), n_bins, labels=False, duplicates="drop").to_numpy()
    rng = np.random.default_rng(seed)
    members = {b: np.where(ok & (bins == b))[0] for b in np.unique(bins) if np.isfinite(b)}
    pool: dict[int, np.ndarray] = {}
    for i in range(len(mean_expr)):
        b = bins[i]
        cand = members.get(b, np.array([], dtype=int))
        cand = cand[cand != i]
        if len(cand) > n_ctrl:
            cand = rng.choice(cand, size=n_ctrl, replace=False)
        pool[i] = cand
    return pool


def addmodule_score(
    x: sp.csr_matrix,
    genes: list[str],
    gene_index: dict[str, int],
    pool: dict[int, np.ndarray],
) -> np.ndarray:
    idx = [gene_index[g] for g in genes if g in gene_index]
    if not idx:
        return np.full(x.shape[0], np.nan)
    prog = x[:, idx].toarray().astype(np.float64).mean(axis=1)
    ctrl_idx = np.unique(np.concatenate([pool[i] for i in idx if len(pool[i]) > 0]))
    if len(ctrl_idx) == 0:
        return prog
    ctrl = np.asarray(x[:, ctrl_idx].mean(axis=1)).ravel().astype(np.float64)
    return prog - ctrl


def ucell_score(x: sp.csr_matrix, genes: list[str], gene_index: dict[str, int]) -> np.ndarray:
    idx = np.array([gene_index[g] for g in genes if g in gene_index], dtype=np.int32)
    if len(idx) == 0:
        return np.full(x.shape[0], np.nan)
    idx_set = set(idx.tolist())
    out = np.full(x.shape[0], np.nan, dtype=np.float64)
    n_genes = np.zeros(x.shape[0], dtype=np.int32)
    indptr, indices, data = x.indptr, x.indices, x.data
    for j in range(x.shape[0]):
        s, e = indptr[j], indptr[j + 1]
        rows = indices[s:e]
        vals = data[s:e]
        keep = vals > 0
        rows, vals = rows[keep], vals[keep]
        n_genes[j] = len(rows)
        if len(rows) < 50:
            continue
        order = np.argsort(-vals, kind="stable")
        ranks = np.empty(len(rows), dtype=np.int32)
        ranks[order] = np.arange(1, len(rows) + 1)
        # map row -> rank via a dict only for program genes
        rank_map = dict(zip(rows.tolist(), ranks.tolist()))
        present = [rank_map[i] for i in idx_set if i in rank_map]
        if present:
            out[j] = 1.0 - (min(present) - 1) / len(rows)
    return out


def downsample_counts(mat: sp.csr_matrix, target: int, seed: int = 7) -> tuple[sp.csr_matrix, np.ndarray]:
    """Binomial thinning of each cell to ~target UMIs. mat: genes x cells CSR."""
    m = mat.T.tocsr().astype(np.int32)  # cells x genes
    rng = np.random.default_rng(seed)
    indptr, indices, data = m.indptr, m.indices, m.data
    new_data = np.zeros_like(data, dtype=np.float32)
    new_tot = np.zeros(m.shape[0], dtype=np.int64)
    for i in range(m.shape[0]):
        s, e = indptr[i], indptr[i + 1]
        vals = data[s:e].astype(np.int64)
        n = int(vals.sum())
        if n == 0:
            continue
        if n <= target:
            new = vals
        else:
            p = target / n
            new = rng.binomial(vals, p)
        new_data[s:e] = new
        new_tot[i] = new.sum()
    out = sp.csr_matrix((new_data, indices, indptr), shape=m.shape)
    return out.T.tocsr(), new_tot


def fisher_ci(r: float, n: int) -> tuple[float, float]:
    if not np.isfinite(r) or n < 4:
        return np.nan, np.nan
    z = np.arctanh(np.clip(r, -0.999999, 0.999999))
    se = 1 / np.sqrt(n - 3)
    return float(np.tanh(z - 1.96 * se)), float(np.tanh(z + 1.96 * se))


def partial_spearman(df: pd.DataFrame, x: str, y: str, covars: list[str]) -> tuple[float, float, int]:
    sub = df[[x, y] + covars].dropna()
    if len(sub) < 50:
        return np.nan, np.nan, len(sub)
    r = sub.rank()
    X = np.column_stack([np.ones(len(r))] + [r[c].to_numpy(dtype=float) for c in covars])
    bx, *_ = np.linalg.lstsq(X, r[x].to_numpy(dtype=float), rcond=None)
    by, *_ = np.linalg.lstsq(X, r[y].to_numpy(dtype=float), rcond=None)
    rx = r[x].to_numpy(dtype=float) - X @ bx
    ry = r[y].to_numpy(dtype=float) - X @ by
    rho, p = stats.pearsonr(rx, ry)
    return float(rho), float(p), len(sub)


def meta_random_effects(rows: pd.DataFrame) -> pd.DataFrame:
    out = []
    for (method, cell_type), sub in rows.groupby(["method", "cell_type"]):
        sub = sub.dropna(subset=["rho", "n"])
        sub = sub[sub["n"] > 3]
        if len(sub) == 0:
            continue
        z = np.arctanh(np.clip(sub["rho"].to_numpy(), -0.999999, 0.999999))
        v = 1.0 / (sub["n"].to_numpy() - 3)
        w = 1.0 / v
        z_fe = np.sum(w * z) / np.sum(w)
        Q = np.sum(w * (z - z_fe) ** 2)
        dfree = len(z) - 1
        C = np.sum(w) - np.sum(w ** 2) / np.sum(w)
        tau2 = max(0.0, (Q - dfree) / C) if dfree > 0 and C > 0 else 0.0
        wr = 1.0 / (v + tau2)
        z_re = np.sum(wr * z) / np.sum(wr)
        se = np.sqrt(1.0 / np.sum(wr))
        out.append(
            {
                "method": method,
                "cell_type": cell_type,
                "k_samples": len(sub),
                "pooled_r": float(np.tanh(z_re)),
                "ci_low": float(np.tanh(z_re - 1.96 * se)),
                "ci_high": float(np.tanh(z_re + 1.96 * se)),
                "I2": float(max(0.0, (Q - dfree) / Q) * 100) if Q > 0 else 0.0,
            }
        )
    return pd.DataFrame(out)


def main():
    L, M = load_genesets()
    all_genes = set(L) | set(M) | {g for v in SUBMODULES.values() for g in v}
    corr_rows = []
    module_rows = []
    percell = {}

    for sample, (series, subdir, target) in SAMPLES.items():
        t0 = time.time()
        sdir = os.path.join(ROOT, "incoming", series, subdir)
        log(f"loading {sample} from {sdir}")
        mat, genes, barcodes = load_matrix(sdir)
        gene_index = {g: i for i, g in enumerate(genes)}
        meta = pd.read_csv(os.path.join(ROOT, f"{sample}_cell_scores.tsv.gz"), sep="\t")
        meta = meta.set_index("cell_id").reindex(barcodes).reset_index()
        meta = meta.rename(columns={"index": "cell_id"})
        keep = meta["cell_type"].notna().to_numpy()
        mat = mat[:, keep]
        barcodes = barcodes[keep]
        meta = meta.loc[keep].reset_index(drop=True)

        x = normalize_log(mat)
        mean_expr = np.asarray(x.mean(axis=0)).ravel()
        detection = np.asarray((x > 0).mean(axis=0)).ravel()
        exclude = {gene_index[g] for g in all_genes if g in gene_index}
        pool = build_control_pool(mean_expr, detection, exclude)

        log(f"  cells={x.shape[0]}, genes={x.shape[1]}; computing raw scores")
        res = pd.DataFrame({"cell_id": barcodes})
        res["cell_type"] = meta["cell_type"].to_numpy()
        res["cluster"] = meta["cluster"].to_numpy()
        res["n_genes"] = meta["n_genes_by_counts"].to_numpy()
        res["total_counts"] = meta["total_counts"].to_numpy()
        res["L_zmean"] = zmean_score(x, L, gene_index)
        res["M_zmean"] = zmean_score(x, M, gene_index)
        res["L_add"] = addmodule_score(x, L, gene_index, pool)
        res["M_add"] = addmodule_score(x, M, gene_index, pool)
        res["L_ucell"] = ucell_score(x, L, gene_index)
        res["M_ucell"] = ucell_score(x, M, gene_index)
        for name, gs in SUBMODULES.items():
            res[f"{name}_add"] = addmodule_score(x, gs, gene_index, pool)

        log(f"  downsampling to {target} UMIs")
        ds, ds_tot = downsample_counts(mat, target)
        xd = normalize_log(ds)
        res["total_counts_down"] = ds_tot
        res["n_genes_down"] = np.asarray((ds > 0).sum(axis=0)).ravel()
        res["L_down_zmean"] = zmean_score(xd, L, gene_index)
        res["M_down_zmean"] = zmean_score(xd, M, gene_index)
        res["L_down_add"] = addmodule_score(xd, L, gene_index, pool)
        res["M_down_add"] = addmodule_score(xd, M, gene_index, pool)
        res["L_down_ucell"] = ucell_score(xd, L, gene_index)
        res["M_down_ucell"] = ucell_score(xd, M, gene_index)
        for name, gs in SUBMODULES.items():
            res[f"{name}_down_add"] = addmodule_score(xd, gs, gene_index, pool)

        res.to_csv(os.path.join(OUT, f"percell_{sample}.tsv.gz"), sep="\t", index=False, compression="gzip")
        percell[sample] = res

        methods = [
            ("zmean_raw", "L_zmean", "M_zmean", ["n_genes"]),
            ("add_raw", "L_add", "M_add", ["n_genes"]),
            ("ucell_raw", "L_ucell", "M_ucell", ["n_genes"]),
            ("zmean_down", "L_down_zmean", "M_down_zmean", []),
            ("add_down", "L_down_add", "M_down_add", []),
            ("ucell_down", "L_down_ucell", "M_down_ucell", []),
        ]
        for ct, sub in res.groupby("cell_type"):
            if len(sub) < 50:
                continue
            for method, cx, cy, covars in methods:
                d = sub if not covars else sub[sub["n_genes"] >= 200]
                if len(d) < 50:
                    continue
                rho, p = stats.spearmanr(d[cx], d[cy], nan_policy="omit")
                lo, hi = fisher_ci(float(rho), len(d))
                prow = {
                    "sample": sample,
                    "cell_type": ct,
                    "method": method,
                    "n": len(d),
                    "rho": float(rho),
                    "p": float(p),
                    "ci_low": lo,
                    "ci_high": hi,
                }
                if covars:
                    pr, pp, pn = partial_spearman(d, cx, cy, covars)
                    prow.update({"partial_rho": pr, "partial_p": pp, "partial_n": pn})
                else:
                    pr, pp, pn = partial_spearman(d, cx, cy, ["n_genes_down"])
                    prow.update({"partial_rho": pr, "partial_p": pp, "partial_n": pn})
                corr_rows.append(prow)

        # Submodule vs M in malignant cells.
        for ct in ["Malignant_Osteoblastic", "Myeloid"]:
            sub = res[res["cell_type"] == ct]
            if len(sub) < 50:
                continue
            for name in SUBMODULES:
                for suffix in ["add", "down_add"]:
                    cx, cy = f"{name}_{suffix}", f"M_{suffix}"
                    rho, p = stats.spearmanr(sub[cx], sub[cy], nan_policy="omit")
                    lo, hi = fisher_ci(float(rho), len(sub))
                    depth_col = "n_genes" if suffix == "add" else "n_genes_down"
                    pr, pp, pn = partial_spearman(sub, cx, cy, [depth_col])
                    module_rows.append(
                        {
                            "sample": sample,
                            "cell_type": ct,
                            "module": name,
                            "scale": "raw" if suffix == "add" else "downsampled",
                            "n": len(sub),
                            "rho_M": float(rho),
                            "p": float(p),
                            "ci_low": lo,
                            "ci_high": hi,
                            "partial_rho_M": pr,
                            "partial_p": pp,
                        }
                    )
            # net lactylation potential
            for suffix in ["add", "down_add"]:
                z = lambda c: (sub[c] - sub[c].mean()) / sub[c].std(ddof=0)
                net = z(f"supply_{suffix}") + z(f"writers_{suffix}") - z(f"erasers_{suffix}")
                rho, p = stats.spearmanr(net, sub[f"M_{suffix}"], nan_policy="omit")
                lo, hi = fisher_ci(float(rho), len(sub))
                module_rows.append(
                    {
                        "sample": sample,
                        "cell_type": ct,
                        "module": "net_supply_writers_minus_erasers",
                        "scale": "raw" if suffix == "add" else "downsampled",
                        "n": len(sub),
                        "rho_M": float(rho),
                        "p": float(p),
                        "ci_low": lo,
                        "ci_high": hi,
                        "partial_rho_M": np.nan,
                        "partial_p": np.nan,
                    }
                )

        log(f"  done in {time.time() - t0:.1f}s")

    corr = pd.DataFrame(corr_rows)
    corr.to_csv(os.path.join(OUT, "correlation_summary.tsv"), sep="\t", index=False)
    meta_df = meta_random_effects(corr)
    meta_df.to_csv(os.path.join(OUT, "meta_summary.tsv"), sep="\t", index=False)
    mod = pd.DataFrame(module_rows)
    mod.to_csv(os.path.join(OUT, "module_summary.tsv"), sep="\t", index=False)
    log("wrote correlation_summary.tsv, meta_summary.tsv, module_summary.tsv")
    print(meta_df.to_string(index=False))
    print(mod.head(20).to_string(index=False))


if __name__ == "__main__":
    main()
