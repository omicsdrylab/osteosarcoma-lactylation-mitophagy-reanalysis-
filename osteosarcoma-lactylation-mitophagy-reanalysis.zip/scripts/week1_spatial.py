"""Week 1 spatial analysis: composition-adjusted partial correlations with
spatial block-bootstrap confidence intervals."""

from __future__ import annotations

import gzip
import os

import numpy as np
import pandas as pd
from scipy import stats

ROOT = os.path.join(os.environ.get("OSLM_DATA_ROOT", "data"), "A2")
OUT = os.path.join(os.environ.get("OSLM_WORK_ROOT", "work"), "week1")
os.makedirs(OUT, exist_ok=True)

SCORES = os.path.join(ROOT, "A2_week8_spatial_spot_scores.tsv.gz")
POS = {
    "PatientA": os.path.join(ROOT, "incoming", "GSE299025", "PatientA", "tissue_positions_list.csv.gz"),
    "PatientB": os.path.join(ROOT, "incoming", "GSE299025", "PatientB", "tissue_positions_list.csv.gz"),
}

COMPOSITION = ["Osteoblastic", "Hypoxia", "Myeloid", "M2_TAM", "Proliferation"]


def load_positions(path: str) -> pd.DataFrame:
    cols = ["barcode", "in_tissue", "array_row", "array_col", "pxl_row", "pxl_col"]
    return pd.read_csv(path, header=None, names=cols)


def partial_r_np(R: np.ndarray, ix: int, iy: int, icov: list[int], rows: np.ndarray | None = None) -> float:
    if rows is None:
        rows = np.arange(R.shape[0])
    X = np.column_stack([np.ones(len(rows))] + [R[rows, c] for c in icov])
    bx, *_ = np.linalg.lstsq(X, R[rows, ix], rcond=None)
    by, *_ = np.linalg.lstsq(X, R[rows, iy], rcond=None)
    rx = R[rows, ix] - X @ bx
    ry = R[rows, iy] - X @ by
    return float(np.corrcoef(rx, ry)[0, 1])


def block_bootstrap(
    R: np.ndarray,
    ix: int,
    iy: int,
    icov: list[int],
    tile_codes: np.ndarray,
    n_boot: int = 1000,
    seed: int = 11,
) -> tuple[float, float]:
    tiles = np.unique(tile_codes)
    rows_by_tile = {t: np.where(tile_codes == t)[0] for t in tiles}
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(n_boot):
        pick = rng.choice(tiles, size=len(tiles), replace=True)
        rows = np.concatenate([rows_by_tile[t] for t in pick])
        r = partial_r_np(R, ix, iy, icov, rows)
        vals.append(r)
    if len(vals) < 50:
        return np.nan, np.nan
    return float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))


def main():
    scores = pd.read_csv(SCORES, sep="\t")
    rows = []
    for sample, sub in scores.groupby("sample"):
        pos = load_positions(POS[sample])
        d = sub.merge(pos, on="barcode", how="inner")
        print(sample, "spots:", len(d))

        pairs = [
            ("L-M (composition-adjusted)", "L_primary", "M_primary", COMPOSITION),
            ("L-HDAC6_SQSTM1 (M + composition)", "L_primary", "HDAC6_SQSTM1", ["M_primary"] + COMPOSITION),
            ("M-HDAC6_SQSTM1 (L + composition)", "M_primary", "HDAC6_SQSTM1", ["L_primary"] + COMPOSITION),
            ("L-M2_TAM (composition)", "L_primary", "M2_TAM", COMPOSITION),
            ("L-Myeloid (composition)", "L_primary", "Myeloid", COMPOSITION),
            ("L-Osteoblastic (composition)", "L_primary", "Osteoblastic", COMPOSITION),
            ("M-M2_TAM (composition)", "M_primary", "M2_TAM", COMPOSITION),
        ]
        for label, x, y, covars in pairs:
            covars = [c for c in dict.fromkeys(covars) if c not in (x, y)]
            sub = d[[x, y] + covars].dropna()
            cols = [x, y] + covars
            R = sub.rank().to_numpy(dtype=float)
            ix, iy = 0, 1
            icov = list(range(2, 2 + len(covars)))
            r = partial_r_np(R, ix, iy, icov)
            dof = max(1, len(sub) - len(covars) - 2)
            tval = r * np.sqrt(dof / max(1e-12, 1 - r * r))
            p = float(2 * stats.t.sf(abs(tval), dof))
            tile_codes = (
                (d.loc[sub.index, "array_row"] // 8).astype(int).astype(str)
                + "_"
                + (d.loc[sub.index, "array_col"] // 8).astype(int).astype(str)
            ).to_numpy()
            lo, hi = block_bootstrap(R, ix, iy, icov, tile_codes, n_boot=1000)
            raw = stats.spearmanr(sub[x], sub[y])
            rows.append(
                {
                    "sample": sample,
                    "pair": label,
                    "n_spots": len(sub),
                    "raw_rho": float(raw.statistic),
                    "partial_rho": r,
                    "partial_p": p,
                    "ci_low": lo,
                    "ci_high": hi,
                }
            )
            print(f"  {label}: raw={raw.statistic:.3f} partial={r:.3f} [{lo:.3f}, {hi:.3f}]")

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "spatial_partial_bootstrap.tsv"), sep="\t", index=False)
    print("\nSaved:", os.path.join(OUT, "spatial_partial_bootstrap.tsv"))


if __name__ == "__main__":
    main()
