"""Week 2, part 3: bulk program scores + clinical merge.

Computes z-mean scores for L, M, lactylation submodules, HDAC6-SQSTM1,
glycolysis and a net lactylation potential in four bulk cohorts.
"""

from __future__ import annotations

import os

import numpy as np
import pandas as pd

BASE = os.path.join(os.environ.get("OSLM_DATA_ROOT", "data"), "bulk_processed")
GENESETS = os.path.join(os.environ.get("OSLM_DATA_ROOT", "data"), "genesets")
OUT = os.path.join(os.environ.get("OSLM_WORK_ROOT", "work"), "week2")
os.makedirs(OUT, exist_ok=True)


def collapse_genes(df):
    df = df.copy()
    df.index = df.index.astype(str)
    df = df.groupby(level=0).mean()
    return df


def zscore_rows(df):
    df = df.apply(pd.to_numeric, errors="coerce")
    df = df.fillna(df.median(axis=1), axis=0)
    mu = df.mean(axis=1)
    sd = df.std(axis=1, ddof=0).replace(0, np.nan)
    return df.sub(mu, axis=0).div(sd, axis=0)


def score(df_z, genes):
    present = [g for g in genes if g in df_z.index]
    min_required = max(2, int(np.ceil(0.7 * len(genes))))
    if len(present) < min_required:
        return None, len(present)
    s = df_z.loc[present].mean(axis=0)
    return s, len(present)


def main():
    lac = pd.read_csv(os.path.join(GENESETS, "lactylation_genes_v1.tsv"), sep="\t")
    mito = pd.read_csv(os.path.join(GENESETS, "mitophagy_genes_v1.tsv"), sep="\t")
    L = lac.loc[lac["include_primary"] == 1, "gene"].tolist()
    M = mito.loc[mito["include_primary_GO"] == 1, "gene"].tolist()
    programs = {
        "L": L,
        "M": M,
        "supply": ["LDHA", "LDHB", "SLC16A1", "SLC16A3", "SLC16A7", "PKM", "HK1", "HK2", "PFKFB3", "HIF1A"],
        "writers": ["AARS1", "AARS2", "EP300", "CREBBP", "KAT2A", "KAT5", "KAT8"],
        "erasers": ["HDAC1", "HDAC2", "HDAC3", "HDAC6", "SIRT1", "SIRT2", "SIRT3", "SIRT6"],
        "readers": ["BRD9", "DPF2", "BRD4"],
        "HDAC6_SQSTM1": ["HDAC6", "SQSTM1"],
        "glycolysis": ["LDHA", "SLC16A1", "SLC16A3", "PKM", "HK1", "HK2", "PFKFB3", "PFKP", "ENO1", "GAPDH"],
    }

    matrices = {
        "TARGET_OS": ("TARGET_OS_symbol_tpm.tsv.gz", "gene_name"),
        "GSE21257": ("GSE21257_gene_matrix.tsv.gz", "gene"),
        "GSE39055": ("GSE39055_gene_matrix.tsv.gz", "gene"),
        "GSE33382": ("GSE33382_gene_matrix.tsv.gz", "gene"),
        "GSE16091": ("GSE16091_gene_matrix.tsv.gz", "gene"),
    }

    all_scores = []
    for dataset, (fname, gene_col) in matrices.items():
        print("loading", dataset)
        df = pd.read_csv(os.path.join(BASE, fname), sep="\t")
        df = df.set_index(gene_col)
        df = collapse_genes(df)
        if dataset == "TARGET_OS":
            df = np.log2(df.clip(lower=0) + 1)
        z = zscore_rows(df)
        for name, genes in programs.items():
            s, n = score(z, genes)
            if s is None:
                print(f"  skip {name}: only {n} genes")
                continue
            for sid, val in s.items():
                all_scores.append({"dataset": dataset, "sample_id": sid, "score": name, "z": float(val)})
        # L x M
        if "L" in programs and "M" in programs:
            ls, _ = score(z, programs["L"])
            ms, _ = score(z, programs["M"])
            if ls is not None and ms is not None:
                for sid in ls.index:
                    all_scores.append({"dataset": dataset, "sample_id": sid, "score": "LxM", "z": float(ls[sid] * ms[sid])})

    long = pd.DataFrame(all_scores)
    long.to_csv(os.path.join(OUT, "bulk_scores_long.tsv"), sep="\t", index=False)
    wide = long.pivot(index=["dataset", "sample_id"], columns="score", values="z").reset_index()
    wide.to_csv(os.path.join(OUT, "bulk_scores_wide.tsv"), sep="\t", index=False)

    meta = pd.read_csv(os.path.join(BASE, "A1_harmonized_metadata.tsv"), sep="\t")
    clin = pd.read_csv(os.path.join(BASE, "TARGET_OS_clinical_flat.tsv"), sep="\t")
    target_efs = clin[["case_submitter_id", "efs_days", "efs_event", "days_to_death", "vital_status",
                       "days_to_last_follow_up", "metastasis_at_diagnosis_binary"]].copy()
    target_efs = target_efs.rename(columns={"case_submitter_id": "patient_id"})
    meta = meta.merge(target_efs, on="patient_id", how="left")

    # Overall survival time/event for TARGET.
    meta["os_time"] = np.where(meta["vital_status"].eq("Dead"), meta["days_to_death"], meta["days_to_last_follow_up"])
    meta["os_event"] = meta["vital_status"].eq("Dead").astype(float)
    meta.loc[meta["os_time"].isna(), "os_event"] = np.nan

    merged = wide.merge(meta, on=["dataset", "sample_id"], how="left")
    merged.to_csv(os.path.join(OUT, "bulk_scores_clinical.tsv"), sep="\t", index=False)
    print("saved", wide.shape, merged.shape)
    cols = [c for c in ["L", "M", "HDAC6_SQSTM1", "supply"] if c in merged.columns]
    print(merged.groupby("dataset")[cols].mean().round(3).to_string())


if __name__ == "__main__":
    main()
