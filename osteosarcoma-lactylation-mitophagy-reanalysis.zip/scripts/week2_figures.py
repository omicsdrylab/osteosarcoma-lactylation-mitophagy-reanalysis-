"""Week 2 figures: spatial score sensitivity and bulk clinical associations."""

from __future__ import annotations

import os

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyArrowPatch
from scipy import stats

mpl.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 7.5,
        "axes.titlesize": 8.5,
        "axes.labelsize": 7.5,
        "xtick.labelsize": 7,
        "ytick.labelsize": 7,
        "legend.fontsize": 7,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.dpi": 400,
    }
)

W2 = os.path.join(os.environ.get("OSLM_WORK_ROOT", "work"), "week2")
OUT = os.path.join(os.environ.get("OSLM_OUTPUT_ROOT", "outputs"), "week2")
os.makedirs(OUT, exist_ok=True)


def save(fig, name):
    fig.savefig(os.path.join(OUT, f"{name}.pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, f"{name}.png"), bbox_inches="tight", dpi=400)
    plt.close(fig)


def fig4():
    sens = pd.read_csv(os.path.join(W2, "spatial_score_sensitivity.tsv"), sep="\t")
    spot = pd.read_csv(os.path.join(W2, "spatial_score_sensitivity_per_spot.tsv.gz"), sep="\t")
    deconv = pd.read_csv(os.path.join(W2, "spatial_spot_deconv_scores.tsv.gz"), sep="\t")

    # Add AddModuleScore L-M correlation.
    rows = []
    for s, d in deconv.groupby("sample"):
        r = stats.spearmanr(d["L_add"], d["M_add"])
        rl = stats.spearmanr(d["L_add"], d["n_genes"])
        rm = stats.spearmanr(d["M_add"], d["n_genes"])
        rows.append({"sample": s, "method": "addmodule", "n": len(d), "rho": r.statistic, "p": r.pvalue,
                     "rho_L_depth": rl.statistic, "rho_M_depth": rm.statistic})
    sens = pd.concat([sens, pd.DataFrame(rows)], ignore_index=True)
    methods = ["raw_zmean", "addmodule", "residual_zmean", "ucell"]
    labels = ["Raw\nz-mean", "AddModule\nScore", "Residual\nz-mean", "UCell"]
    colors = ["#9E9E9E", "#DD8452", "#4C72B0", "#C44E52"]

    fig = plt.figure(figsize=(7.2, 5.6))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.0, 1.0], hspace=0.48, wspace=0.34)

    axa = fig.add_subplot(gs[0, 0])
    x = np.arange(len(methods))
    for k, (patient, off) in enumerate([("PatientA", -0.18), ("PatientB", 0.18)]):
        vals = [float(sens[(sens["sample"] == patient) & (sens["method"] == m)]["rho"].iloc[0]) for m in methods]
        axa.bar(x + off, vals, width=0.34, color=colors, edgecolor="black", linewidth=0.4,
                hatch="" if k == 0 else "///", label=patient)
    axa.axhline(0, color="#666666", lw=0.6)
    axa.set_xticks(x)
    axa.set_xticklabels(labels)
    axa.set_ylabel("L–M Spearman ρ")
    axa.set_ylim(-0.05, 0.75)
    axa.set_title("Score construction determines coupling")
    axa.legend(frameon=False, loc="upper right")
    axa.text(-0.18, 1.05, "a", transform=axa.transAxes, fontsize=11, fontweight="bold")

    axb = fig.add_subplot(gs[0, 1])
    mat = np.full((len(methods), 2), np.nan)
    for i, m in enumerate(methods):
        for j, patient in enumerate(["PatientA", "PatientB"]):
            sub = sens[(sens["sample"] == patient) & (sens["method"] == m)]
            if len(sub):
                mat[i, j] = np.mean([abs(sub["rho_L_depth"].iloc[0]), abs(sub["rho_M_depth"].iloc[0])])
    # raw/UCell depth values are in the table; addmodule depth values were near zero.
    im = axb.imshow(mat, cmap="Reds", vmin=0, vmax=0.85, aspect="auto")
    axb.set_xticks([0, 1])
    axb.set_xticklabels(["PatientA", "PatientB"])
    axb.set_yticks(range(len(methods)))
    axb.set_yticklabels(labels)
    for i in range(len(methods)):
        for j in range(2):
            if np.isfinite(mat[i, j]):
                axb.text(j, i, f"{mat[i, j]:.2f}", ha="center", va="center", fontsize=7)
    axb.set_title("Mean |ρ| with spot depth")
    axb.text(-0.30, 1.05, "b", transform=axb.transAxes, fontsize=11, fontweight="bold")

    # c: residual z-mean scatter
    axc = fig.add_subplot(gs[1, 0])
    for patient, color in [("PatientA", "#C44E52"), ("PatientB", "#4C72B0")]:
        d = spot[(spot["sample"] == patient) & (spot["method"] == "residual_zmean")]
        axc.scatter(d["L"], d["M"], s=3, alpha=0.25, color=color, linewidth=0, label=patient)
    axc.axhline(0, color="#999999", lw=0.4)
    axc.axvline(0, color="#999999", lw=0.4)
    axc.set_xlabel("Residual L score")
    axc.set_ylabel("Residual M score")
    axc.set_title("Depth-controlled spots")
    axc.legend(frameon=False, markerscale=2)
    axc.text(-0.20, 1.05, "c", transform=axc.transAxes, fontsize=11, fontweight="bold")

    # d: summary arrows
    axd = fig.add_subplot(gs[1, 1])
    axd.set_axis_off()
    axd.text(0.02, 0.88, "Apparent → adjusted", fontsize=9, fontweight="bold", transform=axd.transAxes)
    axd.text(0.02, 0.70, "Raw z-mean:  ρ = 0.62 / 0.45", fontsize=8, transform=axd.transAxes, color="#333333")
    axd.text(0.02, 0.50, "Remove spot depth (n_genes)", fontsize=8, transform=axd.transAxes, color="#333333")
    axd.text(0.02, 0.30, "Residual z-mean:  ρ = 0.11 / 0.06", fontsize=8, transform=axd.transAxes, color="#4C72B0", fontweight="bold")
    axd.text(0.02, 0.10, "Most of the apparent spatial coupling is a depth/composition artifact.", fontsize=7.2, transform=axd.transAxes, color="#555555")
    axd.add_patch(FancyArrowPatch((0.10, 0.66), (0.10, 0.38), arrowstyle="-|>", mutation_scale=10, lw=1.0, color="#666666", transform=axd.transAxes))
    axd.text(-0.05, 1.05, "d", transform=axd.transAxes, fontsize=11, fontweight="bold")

    save(fig, "Figure4_week2_spatial_sensitivity")


def fig5():
    res = pd.read_csv(os.path.join(W2, "bulk_survival_results.tsv"), sep="\t")
    # Keep one adjusted model per cohort/endpoint.
    keep = (
        ((res["dataset"] == "TARGET_OS") & (res["model"] == "age+sex+metastasis"))
        | ((res["dataset"] == "GSE39055") & (res["model"] == "age+sex"))
        | ((res["dataset"] == "GSE16091") & (res["model"] == "unadjusted"))
        | ((res["dataset"].isin(["GSE21257", "GSE33382"])) & (res["model"] == "age+sex"))
    )
    d = res[keep].copy()
    endpoints = [
        ("TARGET_OS", "EFS", "TARGET EFS"),
        ("TARGET_OS", "OS", "TARGET OS"),
        ("GSE39055", "Recurrence", "GSE39055\nrecurrence"),
        ("GSE39055", "OS", "GSE39055\nOS"),
        ("GSE16091", "OS", "GSE16091\nOS"),
        ("GSE21257", "Metastasis", "GSE21257\nmetastasis"),
        ("GSE33382", "Metastasis5y", "GSE33382\nmetastasis"),
    ]
    scores = ["L", "M", "supply", "writers", "erasers", "readers", "HDAC6_SQSTM1", "glycolysis", "LxM"]
    score_labels = ["L", "M", "Supply", "Writers", "Erasers", "Readers", "HDAC6–\nSQSTM1", "Glycolysis", "L×M"]

    fig = plt.figure(figsize=(7.2, 5.2))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.5, 0.9], hspace=0.65, wspace=0.55)
    axa = fig.add_subplot(gs[0, :])
    for i, sc in enumerate(scores):
        for j, (ds, ep, lab) in enumerate(endpoints):
            row = d[(d["dataset"] == ds) & (d["endpoint"] == ep) & (d["score"] == sc)]
            if len(row) == 0:
                continue
            hr = float(row["HR"].iloc[0])
            p = float(row["p"].iloc[0])
            fdr = float(row["FDR"].iloc[0])
            color = np.log2(np.clip(hr, 1e-3, 1e3))
            size = 18 * min(4.0, -np.log10(max(p, 1e-6)))
            axa.scatter(j, i, s=size, c=[color], cmap="RdBu_r", vmin=-3, vmax=3, edgecolor="black", linewidth=0.3)
            mark = "***" if fdr < 0.05 else ("**" if p < 0.05 else ("*" if p < 0.10 else ""))
            if mark:
                axa.text(j, i - 0.25, mark, ha="center", va="center", fontsize=7)
    axa.set_xticks(range(len(endpoints)))
    axa.set_xticklabels([e[2] for e in endpoints], rotation=0)
    axa.set_yticks(range(len(scores)))
    axa.set_yticklabels(score_labels)
    axa.set_xlim(-0.6, len(endpoints) - 0.4)
    axa.set_ylim(-0.6, len(scores) - 0.4)
    axa.invert_yaxis()
    axa.set_title("Bulk clinical associations (adjusted models)")
    axa.text(-0.12, 1.04, "a", transform=axa.transAxes, fontsize=11, fontweight="bold")
    cbar = fig.colorbar(plt.cm.ScalarMappable(norm=mpl.colors.Normalize(vmin=-3, vmax=3), cmap="RdBu_r"), ax=axa, fraction=0.02, pad=0.01)
    cbar.set_label("log2(HR or OR)")

    axb = fig.add_subplot(gs[1, 0])
    mins = []
    for ds, ep, lab in endpoints:
        sub = d[(d["dataset"] == ds) & (d["endpoint"] == ep)]
        mins.append(float(sub["FDR"].min()) if len(sub) else np.nan)
    axb.bar(range(len(endpoints)), mins, color="#B0B0B0", edgecolor="black", linewidth=0.4)
    axb.axhline(0.05, color="#C44E52", lw=0.8, ls="--")
    axb.set_xticks(range(len(endpoints)))
    axb.set_xticklabels([e[2].replace("\n", " ") for e in endpoints], rotation=35, ha="right")
    axb.set_ylabel("Minimum FDR")
    axb.set_title("All FDR > 0.05")
    axb.text(-0.22, 1.05, "b", transform=axb.transAxes, fontsize=11, fontweight="bold")

    axc = fig.add_subplot(gs[1, 1])
    best = d.sort_values("p").head(8)
    labels = [f"{r.dataset} {r.endpoint}: {r.score}" for r in best.itertuples()]
    y = np.arange(len(best))
    axc.errorbar(best["HR"], y, xerr=[best["HR"] - best["CI_low"], best["CI_high"] - best["HR"]],
                 fmt="o", ms=4, color="#4C72B0", lw=1, capsize=1.5)
    axc.axvline(1, color="#999999", lw=0.7, ls="--")
    axc.set_xscale("log")
    axc.set_xlim(0.2, 50)
    axc.set_yticks(y)
    axc.set_yticklabels(labels, fontsize=5.8)
    axc.yaxis.tick_right()
    axc.yaxis.set_label_position("right")
    axc.tick_params(axis="y", pad=1)
    axc.set_xlabel("HR / OR (log scale)")
    axc.set_title("Top nominal signals (instable)")
    axc.text(-0.42, 1.05, "c", transform=axc.transAxes, fontsize=11, fontweight="bold")

    save(fig, "Figure5_week2_bulk_clinical")


if __name__ == "__main__":
    fig4()
    fig5()
    print("saved to", OUT)
