"""Week 2, part 1: build single-cell reference signatures.

Outputs
-------
week2/signature_celltypes.tsv      mean CPM per major cell type
week2/signature_states.tsv         mean CPM for malignant LM-high / LM-low + other cell types
week2/LMhigh_vs_LMlow_DE.tsv       per-gene log2FC between LM-high and LM-low malignant cells
week2/LM_signature_genes.tsv       top up/down genes used for bulk scoring
"""

from __future__ import annotations

import os
import time

import numpy as np
import pandas as pd
import scipy.io
import scipy.sparse as sp

ROOT = os.path.join(os.environ.get("OSLM_DATA_ROOT", "data"), "A2")
GENESETS = os.path.join(os.environ.get("OSLM_DATA_ROOT", "data"), "genesets")
W1 = os.path.join(os.environ.get("OSLM_WORK_ROOT", "work"), "week1")
OUT = os.path.join(os.environ.get("OSLM_WORK_ROOT", "work"), "week2")
os.makedirs(OUT, exist_ok=True)

SAMPLES = {
    "GSE152048_BC2": ("GSE152048", "BC2"),
    "GSE152048_BC3": ("GSE152048", "BC3"),
    "GSE162454_OS4": ("GSE162454", "OS_4"),
    "GSE318840_Treated1": ("GSE318840", "Treated1"),
    "GSE318840_Recurrent1": ("GSE318840", "Recurrent1"),
}


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def load_matrix(sample_dir):
    features = pd.read_csv(os.path.join(sample_dir, "features.tsv.gz"), sep="\t", header=None)
    barcodes = pd.read_csv(os.path.join(sample_dir, "barcodes.tsv.gz"), sep="\t", header=None)[0].astype(str).to_numpy()
    mat = sp.csr_matrix(scipy.io.mmread(os.path.join(sample_dir, "matrix.mtx.gz")))
    symbols = features[1].astype(str).to_numpy()
    uniq, inv = np.unique(symbols, return_inverse=True)
    agg = sp.csr_matrix(
        (np.ones(len(inv), dtype=np.float32), (inv, np.arange(len(inv)))),
        shape=(len(uniq), len(inv)),
    )
    return (agg @ mat).tocsr(), uniq, barcodes


def pseudobulk_cpm(mat, idx):
    if len(idx) == 0:
        return None
    sub = mat[:, idx]
    counts = np.asarray(sub.sum(axis=1)).ravel().astype(np.float64)
    total = counts.sum()
    if total <= 0:
        return None
    return counts / total * 1e6


def main():
    lac = pd.read_csv(os.path.join(GENESETS, "lactylation_genes_v1.tsv"), sep="\t")
    mito = pd.read_csv(os.path.join(GENESETS, "mitophagy_genes_v1.tsv"), sep="\t")
    program = set(lac.loc[lac["include_primary"] == 1, "gene"]) | set(
        mito.loc[mito["include_primary_GO"] == 1, "gene"]
    )

    ct_frames = []
    state_frames = []
    de_frames = []

    for sample, (series, subdir) in SAMPLES.items():
        log(f"loading {sample}")
        mat, genes, barcodes = load_matrix(os.path.join(ROOT, "incoming", series, subdir))
        gene_index = {g: i for i, g in enumerate(genes)}
        cells = pd.read_csv(os.path.join(W1, f"percell_{sample}.tsv.gz"), sep="\t")
        cells = cells.set_index("cell_id").reindex(barcodes)
        cells = cells.reset_index().rename(columns={"index": "cell_id"})
        cells = cells[cells["cell_type"].notna()].reset_index(drop=True)
        # Align matrix columns to cells (cells order follows barcodes).
        mat = mat[:, cells.index.to_numpy()]

        # Major cell-type signatures.
        for ct, sub in cells.groupby("cell_type"):
            if len(sub) < 30:
                continue
            p = pseudobulk_cpm(mat, sub.index.to_numpy())
            if p is None:
                continue
            ct_frames.append(pd.DataFrame({"gene": genes, "signature": ct, "sample": sample, "cpm": p}))

        # LM-high / LM-low malignant states.
        mal = cells[cells["cell_type"] == "Malignant_Osteoblastic"].copy()
        if len(mal) < 80:
            continue
        z = lambda v: (v - v.mean()) / (v.std(ddof=0) + 1e-9)
        comp = z(mal["L_down_add"].to_numpy()) + z(mal["M_down_add"].to_numpy())
        q1, q3 = np.quantile(comp, [0.25, 0.75])
        high = mal.index[comp >= q3]
        low = mal.index[comp <= q1]
        if len(high) < 30 or len(low) < 30:
            continue
        ph = pseudobulk_cpm(mat, high)
        pl = pseudobulk_cpm(mat, low)
        if ph is None or pl is None:
            continue
        state_frames.append(pd.DataFrame({"gene": genes, "signature": "Malignant_LMhigh", "sample": sample, "cpm": ph}))
        state_frames.append(pd.DataFrame({"gene": genes, "signature": "Malignant_LMlow", "sample": sample, "cpm": pl}))

        det_h = np.asarray((mat[:, high] > 0).mean(axis=1)).ravel()
        det_l = np.asarray((mat[:, low] > 0).mean(axis=1)).ravel()
        de = pd.DataFrame(
            {
                "gene": genes,
                "sample": sample,
                "log2FC": np.log2((ph + 1) / (pl + 1)),
                "det_high": det_h,
                "det_low": det_l,
                "n_high": len(high),
                "n_low": len(low),
            }
        )
        de_frames.append(de)
        log(f"  {sample}: {len(high)} high / {len(low)} low malignant cells")

    ct = pd.concat(ct_frames, ignore_index=True)
    st = pd.concat(state_frames, ignore_index=True)
    ct_mean = ct.groupby(["gene", "signature"], as_index=False)["cpm"].mean()
    st_mean = st.groupby(["gene", "signature"], as_index=False)["cpm"].mean()
    ct_mat = ct_mean.pivot(index="gene", columns="signature", values="cpm").fillna(0)
    st_mat = st_mean.pivot(index="gene", columns="signature", values="cpm").fillna(0)
    ct_mat.to_csv(os.path.join(OUT, "signature_celltypes.tsv"), sep="\t")
    st_mat.to_csv(os.path.join(OUT, "signature_states.tsv"), sep="\t")

    de = pd.concat(de_frames, ignore_index=True)
    de.to_csv(os.path.join(OUT, "LMhigh_vs_LMlow_DE.tsv"), sep="\t", index=False)
    agg = (
        de.groupby("gene")
        .agg(
            mean_log2FC=("log2FC", "mean"),
            n_samples=("sample", "nunique"),
            n_positive=("log2FC", lambda x: int((x > 0).sum())),
            n_negative=("log2FC", lambda x: int((x < 0).sum())),
            det_high=("det_high", "mean"),
            det_low=("det_low", "mean"),
        )
        .reset_index()
    )
    agg = agg[
        ~agg["gene"].isin(program)
        & ~agg["gene"].str.startswith(("RPL", "RPS", "MT-", "MRPL", "MRPS"))
        & (agg["det_high"] > 0.10)
    ].copy()
    agg["direction"] = np.where(agg["mean_log2FC"] > 0, "up", "down")
    agg["consistency"] = np.where(
        agg["direction"] == "up", agg["n_positive"] / agg["n_samples"], agg["n_negative"] / agg["n_samples"]
    )
    up = agg.sort_values("mean_log2FC", ascending=False).head(150)
    down = agg.sort_values("mean_log2FC").head(150)
    sig = pd.concat([up, down], ignore_index=True)
    sig.to_csv(os.path.join(OUT, "LM_signature_genes.tsv"), sep="\t", index=False)

    log(f"cell-type signatures: {ct_mat.shape}; state signatures: {st_mat.shape}")
    log(f"LM signature: {len(up)} up + {len(down)} down genes")
    print("Top up:", ", ".join(up.head(15)["gene"].tolist()))
    print("Top down:", ", ".join(down.head(15)["gene"].tolist()))


if __name__ == "__main__":
    main()
