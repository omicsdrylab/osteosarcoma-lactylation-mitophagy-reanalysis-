"""Week 2, part 2: spatial deconvolution + re-scoring.

- Build CPM profiles per spot.
- NNLS deconvolution against single-cell major cell-type signatures.
- Recompute AddModuleScore-like L, M and HDAC6-SQSTM1 scores on spots.
- Test whether L-M and axis coupling is stronger in malignant-high spots.
"""

from __future__ import annotations

import os
import time

import numpy as np
import pandas as pd
import scipy.io
import scipy.sparse as sp
from scipy import stats
from scipy.optimize import nnls

ROOT = os.path.join(os.environ.get("OSLM_DATA_ROOT", "data"), "A2")
GENESETS = os.path.join(os.environ.get("OSLM_DATA_ROOT", "data"), "genesets")
W2 = os.path.join(os.environ.get("OSLM_WORK_ROOT", "work"), "week2")
OUT = W2
os.makedirs(OUT, exist_ok=True)

SAMPLES = {
    "PatientA": os.path.join(ROOT, "incoming", "GSE299025", "PatientA"),
    "PatientB": os.path.join(ROOT, "incoming", "GSE299025", "PatientB"),
}


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def load_spatial(sample_dir):
    features = pd.read_csv(os.path.join(sample_dir, "features.tsv.gz"), sep="\t", header=None)
    barcodes = pd.read_csv(os.path.join(sample_dir, "barcodes.tsv.gz"), sep="\t", header=None)[0].astype(str).to_numpy()
    mat = sp.csr_matrix(scipy.io.mmread(os.path.join(sample_dir, "matrix.mtx.gz")))
    symbols = features[1].astype(str).to_numpy()
    uniq, inv = np.unique(symbols, return_inverse=True)
    agg = sp.csr_matrix(
        (np.ones(len(inv), dtype=np.float32), (inv, np.arange(len(inv)))),
        shape=(len(uniq), len(inv)),
    )
    mat = (agg @ mat).tocsr()
    positions = pd.read_csv(
        os.path.join(sample_dir, "tissue_positions_list.csv.gz"),
        header=None,
        names=["barcode", "in_tissue", "array_row", "array_col", "pxl_row", "pxl_col"],
    )
    return mat, uniq, barcodes, positions


def cpm(mat):
    x = mat.T.tocsr().astype(np.float32)  # spots x genes
    lib = np.asarray(x.sum(axis=1)).ravel()
    lib[lib == 0] = 1.0
    x.data *= np.repeat(1e6 / lib, np.diff(x.indptr))
    return x


def lognorm(mat):
    x = mat.T.tocsr().astype(np.float32)
    lib = np.asarray(x.sum(axis=1)).ravel()
    lib[lib == 0] = 1.0
    x.data *= np.repeat(1e4 / lib, np.diff(x.indptr))
    x.data = np.log1p(x.data)
    return x


def build_pool(mean_expr, exclude, n_bins=25, n_ctrl=50, seed=13):
    ok = np.ones(len(mean_expr), dtype=bool)
    ok[list(exclude)] = False
    ok &= np.isfinite(mean_expr)
    bins = pd.qcut(pd.Series(mean_expr), n_bins, labels=False, duplicates="drop").to_numpy()
    members = {b: np.where(ok & (bins == b))[0] for b in np.unique(bins) if np.isfinite(b)}
    rng = np.random.default_rng(seed)
    pool = {}
    for i in range(len(mean_expr)):
        cand = members.get(bins[i], np.array([], dtype=int))
        cand = cand[cand != i]
        if len(cand) > n_ctrl:
            cand = rng.choice(cand, size=n_ctrl, replace=False)
        pool[i] = cand
    return pool


def ams(x, genes, gene_index, pool):
    idx = [gene_index[g] for g in genes if g in gene_index]
    if not idx:
        return np.full(x.shape[0], np.nan)
    prog = x[:, idx].toarray().mean(axis=1)
    ctrl_idx = np.unique(np.concatenate([pool[i] for i in idx if len(pool[i]) > 0]))
    ctrl = np.asarray(x[:, ctrl_idx].mean(axis=1)).ravel()
    return prog - ctrl


def partial_spearman(df, x, y, covars):
    covars = [c for c in dict.fromkeys(covars) if c not in (x, y)]
    sub = df[[x, y] + covars].dropna()
    if len(sub) < 50:
        return np.nan, np.nan, len(sub)
    r = sub.rank()
    X = np.column_stack([np.ones(len(r))] + [r[c].to_numpy(float) for c in covars])
    bx, *_ = np.linalg.lstsq(X, r[x].to_numpy(float), rcond=None)
    by, *_ = np.linalg.lstsq(X, r[y].to_numpy(float), rcond=None)
    rx = r[x].to_numpy(float) - X @ bx
    ry = r[y].to_numpy(float) - X @ by
    rho, p = stats.pearsonr(rx, ry)
    return float(rho), float(p), len(sub)


def block_bootstrap(df, x, y, covars, n_boot=1000, tile=8, seed=11):
    covars = [c for c in dict.fromkeys(covars) if c not in (x, y)]
    sub = df[[x, y] + covars].dropna()
    R = sub.rank().to_numpy(float)
    icov = list(range(2, 2 + len(covars)))
    tile_codes = (
        (df.loc[sub.index, "array_row"] // tile).astype(int).astype(str)
        + "_"
        + (df.loc[sub.index, "array_col"] // tile).astype(int).astype(str)
    ).to_numpy()
    tiles = np.unique(tile_codes)
    rows_by_tile = {t: np.where(tile_codes == t)[0] for t in tiles}
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(n_boot):
        pick = rng.choice(tiles, size=len(tiles), replace=True)
        rows = np.concatenate([rows_by_tile[t] for t in pick])
        X = np.column_stack([np.ones(len(rows))] + [R[rows, c] for c in icov])
        bx, *_ = np.linalg.lstsq(X, R[rows, 0], rcond=None)
        by, *_ = np.linalg.lstsq(X, R[rows, 1], rcond=None)
        rx = R[rows, 0] - X @ bx
        ry = R[rows, 1] - X @ by
        vals.append(np.corrcoef(rx, ry)[0, 1])
    return float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))


def main():
    sig = pd.read_csv(os.path.join(W2, "signature_celltypes.tsv"), sep="\t", index_col=0)
    sig = sig.loc[sig.index.drop_duplicates()]
    log(f"signature matrix: {sig.shape}")

    # Curated, cell-type-specific markers (avoid data-driven junk genes).
    CURATED = {
        "Malignant_Osteoblastic": ["SP7", "RUNX2", "ALPL", "IBSP", "SPP1", "MMP13", "SATB2", "COL1A1", "COL1A2", "COL3A1", "FN1", "POSTN", "VIM", "TWIST1", "ZEB1"],
        "Myeloid": ["CD68", "CD14", "LYZ", "AIF1", "C1QA", "C1QB", "C1QC", "CSF1R", "ITGAM", "FCGR3A", "MSR1", "CD163", "TYROBP", "FCER1G", "LILRB1"],
        "T_NK": ["CD3D", "CD3E", "CD2", "NKG7", "GNLY", "KLRD1", "CD8A", "IL7R", "CCL5", "GZMB", "PRF1", "TRAC", "TRBC2", "CD247", "KLRB1"],
        "B_Plasma": ["CD79A", "MS4A1", "MZB1", "JCHAIN", "IGKC", "IGHG1", "DERL3", "SDC1", "CD19", "CD37", "CD74", "HLA-DRA", "LTB", "CR2", "PAX5"],
        "Endothelial": ["PECAM1", "VWF", "KDR", "EMCN", "PLVAP", "CLDN5", "CDH5", "ESAM", "ROBO4", "ENG", "TIE1", "FLT1", "AQP1", "CAV1", "RAMP2"],
        "Fibroblast": ["DCN", "LUM", "PDGFRA", "THY1", "FAP", "POSTN", "COL1A2", "COL3A1", "MFAP5", "PDPN", "NT5E", "SFRP2", "C7", "CFH", "GPX3"],
        "Chondrocyte": ["ACAN", "COL2A1", "SOX9", "COMP", "MATN3", "COL9A1", "COL11A1", "CHAD", "HAPLN1", "LECT1", "COL9A2", "COL9A3", "S100B", "CLEC3A", "EFEMP1"],
    }
    markers_by_type = {}
    for c, gs in CURATED.items():
        if c not in sig.columns:
            continue
        present = [g for g in gs if g in sig.index]
        if len(present) >= 5:
            markers_by_type[c] = present
    cell_types = list(markers_by_type)
    markers = sorted({g for gs in markers_by_type.values() for g in gs})
    log(f"curated marker genes: {len(markers)} across {len(cell_types)} cell types")
    for c, gs in markers_by_type.items():
        log(f"  {c}: {len(gs)} markers")

    # Keep the old data-driven block below disabled for reference.
    """
    house = (
        sig.index.str.startswith(("MT-", "RPL", "RPS", "MRPL", "MRPS"))
        | sig.index.isin(
            [
                "MALAT1",
                "FTL",
                "FTH1",
                "B2M",
                "TMSB4X",
                "ACTB",
                "GAPDH",
                "EEF1A1",
                "EEF1B2",
                "EEF2",
                "UBC",
                "UBA52",
                "HSP90AA1",
                "HSP90AB1",
                "HSPA1A",
                "HSPA1B",
                "TUBB",
                "TUBA1B",
            ]
        )
    )
    sig_clean = sig.loc[~house]
    markers = set()
    for c in sig_clean.columns:
        other = sig_clean.drop(columns=c).max(axis=1)
        logfc = np.log2((sig_clean[c] + 1) / (other + 1))
        cand = logfc[(logfc > 1.0) & (sig_clean[c] > 10)].sort_values(ascending=False).head(100).index
        markers |= set(cand)
    markers = list(markers)
    log(f"marker genes after housekeeping removal: {len(markers)}")
    for c in sig_clean.columns:
        other = sig_clean.drop(columns=c).max(axis=1)
        logfc = np.log2((sig_clean[c] + 1) / (other + 1))
        top = logfc[(logfc > 1.0) & (sig_clean[c] > 10)].sort_values(ascending=False).head(8).index.tolist()
        log(f"  {c}: {', '.join(top)}")
    """

    lac = pd.read_csv(os.path.join(GENESETS, "lactylation_genes_v1.tsv"), sep="\t")
    mito = pd.read_csv(os.path.join(GENESETS, "mitophagy_genes_v1.tsv"), sep="\t")
    L = lac.loc[lac["include_primary"] == 1, "gene"].tolist()
    M = mito.loc[mito["include_primary_GO"] == 1, "gene"].tolist()
    SUB = {
        "supply": ["LDHA", "LDHB", "SLC16A1", "SLC16A3", "SLC16A7", "PKM", "HK1", "HK2", "PFKFB3", "HIF1A"],
        "writers": ["AARS1", "AARS2", "EP300", "CREBBP", "KAT2A", "KAT5", "KAT8"],
        "erasers": ["HDAC1", "HDAC2", "HDAC3", "HDAC6", "SIRT1", "SIRT2", "SIRT3", "SIRT6"],
        "readers": ["BRD9", "DPF2", "BRD4"],
    }
    all_program = set(L) | set(M) | {g for v in SUB.values() for g in v}

    rows = []
    for sample, sdir in SAMPLES.items():
        log(f"loading {sample}")
        mat, genes, barcodes, pos = load_spatial(sdir)
        gene_index = {g: i for i, g in enumerate(genes)}
        x_cpm = cpm(mat)
        x_log = lognorm(mat)
        mean_expr = np.asarray(x_log.mean(axis=0)).ravel()
        exclude = {gene_index[g] for g in all_program if g in gene_index}
        pool = build_pool(mean_expr, exclude)

        # Deconvolution on marker genes.
        mk = [g for g in markers if g in gene_index and g in sig.index]
        A = sig.loc[mk, cell_types].to_numpy(float)
        B = x_cpm[:, [gene_index[g] for g in mk]].toarray().T  # spots x markers
        n_spots = B.shape[1]
        props = np.zeros((n_spots, len(cell_types)))
        for i in range(n_spots):
            coef, _ = nnls(A, B[:, i])
            s = coef.sum()
            props[i] = coef / s if s > 0 else np.nan
        prop_df = pd.DataFrame(props, columns=[f"prop_{c}" for c in cell_types])
        prop_df.insert(0, "barcode", barcodes)

        df = pd.DataFrame({"barcode": barcodes})
        df["n_genes"] = np.asarray((mat > 0).sum(axis=0)).ravel()
        df["total_counts"] = np.asarray(mat.sum(axis=0)).ravel()
        df["L_add"] = ams(x_log, L, gene_index, pool)
        df["M_add"] = ams(x_log, M, gene_index, pool)
        df["HDAC6_SQSTM1"] = ams(x_log, ["HDAC6", "SQSTM1"], gene_index, pool)
        for name, gs in SUB.items():
            df[f"{name}_add"] = ams(x_log, gs, gene_index, pool)
        for c, gs in markers_by_type.items():
            df[f"score_{c}"] = ams(x_log, gs, gene_index, pool)
        df = df.merge(prop_df, on="barcode").merge(pos, on="barcode", how="inner")
        df["sample"] = sample

        df["malignant_prop"] = df.get("prop_Malignant_Osteoblastic", np.nan)
        df["myeloid_prop"] = df.get("prop_Myeloid", np.nan)
        df["lm_score"] = df["L_add"] + df["M_add"]
        rows.append(df)
        log(f"  spots={len(df)}, mean malignant prop={df['malignant_prop'].mean():.3f}, myeloid={df['myeloid_prop'].mean():.3f}")

    all_df = pd.concat(rows, ignore_index=True)
    all_df.to_csv(os.path.join(OUT, "spatial_spot_deconv_scores.tsv.gz"), sep="\t", index=False, compression="gzip")

    # Validation and association tests.
    out = []
    for sample, d in all_df.groupby("sample"):
        val1 = stats.spearmanr(d["malignant_prop"], d["L_add"])
        val2 = stats.spearmanr(d["myeloid_prop"], d["M_add"])
        out.append({"sample": sample, "test": "malignant_prop_vs_L", "rho": val1.statistic, "p": val1.pvalue})
        out.append({"sample": sample, "test": "myeloid_prop_vs_M", "rho": val2.statistic, "p": val2.pvalue})
        for c in [x for x in d.columns if x.startswith("score_")]:
            for focal in ["L_add", "M_add", "HDAC6_SQSTM1"]:
                r = stats.spearmanr(d[c], d[focal], nan_policy="omit")
                out.append({"sample": sample, "test": f"{c}_vs_{focal}", "rho": r.statistic, "p": r.pvalue})

        d = d.copy()
        d["malignant_tertile"] = pd.qcut(d["malignant_prop"].rank(method="first"), 3, labels=["low", "mid", "high"])
        d["myeloid_tertile"] = pd.qcut(d["myeloid_prop"].rank(method="first"), 3, labels=["low", "mid", "high"])
        d["malignant_score_tertile"] = pd.qcut(d["score_Malignant_Osteoblastic"].rank(method="first"), 3, labels=["low", "mid", "high"])
        d["myeloid_score_tertile"] = pd.qcut(d["score_Myeloid"].rank(method="first"), 3, labels=["low", "mid", "high"])
        comp = ["prop_Malignant_Osteoblastic", "prop_Myeloid", "prop_Fibroblast", "prop_Endothelial", "prop_T_NK", "prop_B_Plasma"]
        comp = [c for c in comp if c in d.columns]
        for label, sub in [
            ("malignant_score_high", d[d["malignant_score_tertile"] == "high"]),
            ("myeloid_score_high", d[d["myeloid_score_tertile"] == "high"]),
            ("all", d),
        ]:
            r, p, n = partial_spearman(sub, "L_add", "M_add", ["n_genes"] + comp)
            out.append({"sample": sample, "test": f"L_M_{label}", "rho": r, "p": p, "n": n})
            for axis in ["HDAC6_SQSTM1"]:
                r2, p2, n2 = partial_spearman(sub, "L_add", axis, ["M_add"] + comp)
                out.append({"sample": sample, "test": f"L_{axis}_{label}", "rho": r2, "p": p2, "n": n2})
                r3, p3, n3 = partial_spearman(sub, "M_add", axis, ["L_add"] + comp)
                out.append({"sample": sample, "test": f"M_{axis}_{label}", "rho": r3, "p": p3, "n": n3})

    res = pd.DataFrame(out)
    res.to_csv(os.path.join(OUT, "spatial_deconv_associations.tsv"), sep="\t", index=False)
    print(res.to_string(index=False))


if __name__ == "__main__":
    main()
