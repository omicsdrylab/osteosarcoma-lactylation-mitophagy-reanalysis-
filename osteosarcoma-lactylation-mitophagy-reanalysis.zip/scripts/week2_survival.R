suppressPackageStartupMessages(library(survival))

infile <- "bulk_scores_clinical.tsv"
outfile <- "bulk_survival_results.tsv"
d <- read.delim(infile, check.names = FALSE, stringsAsFactors = FALSE)
d$sex <- factor(d$sex)

scores <- c("L", "M", "supply", "writers", "erasers", "readers",
            "HDAC6_SQSTM1", "glycolysis", "LxM")

cox_one <- function(dat, time, event, score, covars, dataset, endpoint, model) {
  if (!score %in% names(dat)) return(NULL)
  vars <- c(time, event, score, covars)
  x <- dat[complete.cases(dat[, vars, drop = FALSE]), , drop = FALSE]
  x <- x[x[[time]] > 0 & !is.na(x[[time]]) & !is.na(x[[event]]), , drop = FALSE]
  if (nrow(x) < 20 || sum(x[[event]], na.rm = TRUE) < 5) return(NULL)
  f <- as.formula(paste0("Surv(", time, ", ", event, ") ~ ",
                         paste(c(score, covars), collapse = " + ")))
  fit <- tryCatch(coxph(f, data = x, ties = "efron"),
                  error = function(e) NULL)
  if (is.null(fit)) return(NULL)
  s <- summary(fit)
  co <- s$coefficients
  ci <- s$conf.int
  if (!score %in% rownames(co)) return(NULL)
  data.frame(
    dataset = dataset, endpoint = endpoint, model = model,
    score = score, n = nrow(x), events = sum(x[[event]], na.rm = TRUE),
    HR = ci[score, "exp(coef)"],
    CI_low = ci[score, "lower .95"],
    CI_high = ci[score, "upper .95"],
    p = co[score, "Pr(>|z|)"],
    stringsAsFactors = FALSE
  )
}

logit_one <- function(dat, event, score, covars, dataset, endpoint, model) {
  if (!score %in% names(dat)) return(NULL)
  vars <- c(event, score, covars)
  x <- dat[complete.cases(dat[, vars, drop = FALSE]), , drop = FALSE]
  x <- x[!is.na(x[[event]]), , drop = FALSE]
  if (nrow(x) < 20 || sum(x[[event]]) < 5 || sum(x[[event]]) == nrow(x)) return(NULL)
  f <- as.formula(paste0(event, " ~ ", paste(c(score, covars), collapse = " + ")))
  fit <- tryCatch(glm(f, data = x, family = binomial()),
                  error = function(e) NULL)
  if (is.null(fit)) return(NULL)
  s <- summary(fit)$coefficients
  if (!score %in% rownames(s)) return(NULL)
  data.frame(
    dataset = dataset, endpoint = endpoint, model = model,
    score = score, n = nrow(x), events = sum(x[[event]]),
    HR = exp(s[score, "Estimate"]),
    CI_low = exp(s[score, "Estimate"] - 1.96 * s[score, "Std. Error"]),
    CI_high = exp(s[score, "Estimate"] + 1.96 * s[score, "Std. Error"]),
    p = s[score, "Pr(>|z|)"],
    stringsAsFactors = FALSE
  )
}

res <- list()
add <- function(z) if (!is.null(z)) res[[length(res) + 1]] <<- z

# TARGET-OS EFS and OS
tg <- d[d$dataset == "TARGET_OS", , drop = FALSE]
for (sc in scores) {
  for (cv in list(c("age_value", "sex"), c("age_value", "sex", "metastasis_at_diagnosis_binary"))) {
    m <- if (length(cv) == 2) "age+sex" else "age+sex+metastasis"
    add(cox_one(tg, "efs_days", "efs_event", sc, cv, "TARGET_OS", "EFS", m))
    add(cox_one(tg, "os_time", "os_event", sc, cv, "TARGET_OS", "OS", m))
  }
}

# GSE39055 recurrence and OS
g55 <- d[d$dataset == "GSE39055", , drop = FALSE]
for (sc in scores) {
  add(cox_one(g55, "time_days", "recurrence_event", sc, c("age_value", "sex"), "GSE39055", "Recurrence", "age+sex"))
  add(cox_one(g55, "time_days", "death_event", sc, c("age_value", "sex"), "GSE39055", "OS", "age+sex"))
}

# GSE16091 OS (no covariates)
g91 <- d[d$dataset == "GSE16091", , drop = FALSE]
for (sc in scores) {
  add(cox_one(g91, "time_days", "death_event", sc, character(0), "GSE16091", "OS", "unadjusted"))
}

# Logistic metastasis endpoints
g57 <- d[d$dataset == "GSE21257", , drop = FALSE]
g82 <- d[d$dataset == "GSE33382", , drop = FALSE]
for (sc in scores) {
  add(logit_one(g57, "metastasis_event", sc, c("age_value", "sex"), "GSE21257", "Metastasis", "age+sex"))
  add(logit_one(g82, "metastasis_event", sc, c("age_value", "sex"), "GSE33382", "Metastasis5y", "age+sex"))
}

out <- do.call(rbind, res)
out$FDR <- ave(out$p, paste(out$dataset, out$endpoint, out$model), FUN = function(p) p.adjust(p, "BH"))
write.table(out, outfile, sep = "\t", row.names = FALSE, quote = FALSE)
cat("saved", nrow(out), "models to", outfile, "\n")
print(out[order(out$p), c("dataset", "endpoint", "model", "score", "n", "events", "HR", "CI_low", "CI_high", "p", "FDR")][1:min(30, nrow(out)), ], row.names = FALSE)
