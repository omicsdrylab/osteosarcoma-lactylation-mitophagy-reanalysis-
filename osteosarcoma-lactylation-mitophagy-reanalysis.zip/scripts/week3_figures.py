"""Week 3 figures: study design and reporting checklist."""

from __future__ import annotations

import os

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

mpl.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 7.5,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "savefig.dpi": 400,
    }
)

OUT = os.path.join(os.environ.get("OSLM_OUTPUT_ROOT", "outputs"), "week3")
os.makedirs(OUT, exist_ok=True)


def box(ax, x, y, w, h, text, fc, fs=7.5, bold=False):
    ax.add_patch(
        FancyBboxPatch(
            (x, y),
            w,
            h,
            boxstyle="round,pad=0.012,rounding_size=0.018",
            linewidth=0.8,
            edgecolor="#555555",
            facecolor=fc,
            transform=ax.transAxes,
        )
    )
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs,
            fontweight="bold" if bold else "normal", transform=ax.transAxes, wrap=True)


def arrow(ax, x1, y1, x2, y2, color="#666666"):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=9,
                                 lw=0.9, color=color, transform=ax.transAxes))


def fig1():
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.set_axis_off()

    box(ax, 0.02, 0.72, 0.30, 0.20,
        "Bulk (5 cohorts)\nTARGET-OS · GSE21257\nGSE39055 · GSE33382\nGSE16091\nEFS · OS · recurrence · metastasis",
        "#E8F0F7", fs=6.2)
    box(ax, 0.35, 0.72, 0.30, 0.20,
        "Single-cell\n5 samples / 3 datasets\nGSE152048 (BC2, BC3)\nGSE162454 (OS_4)\nGSE318840 (Treated1, Recurrent1)",
        "#FDF0E6", fs=6.2)
    box(ax, 0.68, 0.72, 0.30, 0.20,
        "Spatial\n2 Visium samples\nGSE299025\nPatientA · PatientB\n~3,000 spots each",
        "#EAF4EA", fs=6.5)

    ax.text(0.5, 0.955, "A  Multi-scale reanalysis of lactylation–mitophagy scores in osteosarcoma",
            ha="center", va="center", fontsize=10, fontweight="bold", transform=ax.transAxes)

    arrow(ax, 0.17, 0.72, 0.17, 0.63)
    arrow(ax, 0.50, 0.72, 0.50, 0.63)
    arrow(ax, 0.83, 0.72, 0.83, 0.63)

    pipe = [
        ("Score construction\nraw z-mean · AMS\nresidual · UCell", "#F0EDF7"),
        ("Depth control\ndownsampling\nresidualization", "#F7EDED"),
        ("Module decomposition\nsupply · writers\nerasers · readers", "#F2F2F2"),
        ("Specificity\nmatched random\ngene sets", "#EAF4EA"),
        ("Clinical endpoints\nCox · logistic\nFDR", "#E8F0F7"),
    ]
    w, gap = 0.18, 0.015
    for i, (text, color) in enumerate(pipe):
        x = 0.015 + i * (w + gap)
        box(ax, x, 0.43, w, 0.18, text, color, fs=6.5)
        if i < 4:
            arrow(ax, x + w + 0.001, 0.52, x + w + gap - 0.001, 0.52)

    ax.add_patch(
        FancyBboxPatch(
            (0.02, 0.08), 0.96, 0.22,
            boxstyle="round,pad=0.012,rounding_size=0.018",
            linewidth=1.0, edgecolor="#C44E52", facecolor="#FFF6F5",
            transform=ax.transAxes,
        )
    )
    ax.text(0.05, 0.25, "Question", fontsize=8.5, fontweight="bold", color="#C44E52", transform=ax.transAxes)
    ax.text(0.05, 0.18, "Does the reported L–M coupling survive depth and composition control?",
            fontsize=8, transform=ax.transAxes)
    ax.text(0.05, 0.115, "Answer: raw ρ = 0.57–0.62 → depth-controlled ρ = 0.05–0.16; no bulk clinical replication.",
            fontsize=7.4, color="#333333", transform=ax.transAxes)

    fig.savefig(os.path.join(OUT, "Figure1_week3_study_design.pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, "Figure1_week3_study_design.png"), bbox_inches="tight", dpi=400)
    plt.close(fig)


def fig6():
    fig, ax = plt.subplots(figsize=(7.2, 5.6))
    ax.set_axis_off()
    ax.text(0.5, 0.97, "Reporting checklist for lactylation–mitophagy studies",
            ha="center", va="center", fontsize=10.5, fontweight="bold", transform=ax.transAxes)

    flow = ["Define\nconstruct", "Separate\nmodules", "Control\ndepth", "Matched\nnull", "Independent\nunit", "Validate\nprotein"]
    w, gap = 0.145, 0.022
    for i, t in enumerate(flow):
        x = 0.02 + i * (w + gap)
        box(ax, x, 0.80, w, 0.12, t, "#E8F0F7" if i < 3 else "#FDF0E6", fs=6.7, bold=True)
        if i < len(flow) - 1:
            arrow(ax, x + w + 0.001, 0.86, x + w + gap - 0.001, 0.86)

    items = [
        ("1", "State whether the score measures machinery,\nlactate supply, or the modification itself."),
        ("2", "Report writers, erasers, readers and supply\nseparately; avoid a single composite as a\nsurrogate for lactylation level."),
        ("3", "Correlate every score with detected genes\nand counts; report the result."),
        ("4", "Prefer downsampling, AddModuleScore or\nresidualization; do not rely on raw z-mean\nor UCell alone."),
        ("5", "Compare with expression- and detection-\nmatched random gene sets."),
        ("6", "Remove axis genes from parent scores or\ndefine axes a priori; avoid circular bridges."),
        ("7", "Use samples, not cells or spots, as the\nindependent unit; pseudobulk or mixed models."),
        ("8", "Adjust for malignant, immune and stromal\ncontent; validate deconvolution against\nmarker scores."),
        ("9", "Pre-specify endpoints; report FDR across\nmodules and endpoints."),
        ("10", "Require H3K18la/pan-Kla or mitophagy-flux\ndata before causal or therapeutic claims."),
    ]
    for i, (num, text) in enumerate(items):
        col = i % 2
        row = i // 2
        x = 0.03 + col * 0.49
        y = 0.66 - row * 0.135
        ax.add_patch(
            FancyBboxPatch(
                (x, y), 0.45, 0.115,
                boxstyle="round,pad=0.010,rounding_size=0.014",
                linewidth=0.6, edgecolor="#AAAAAA", facecolor="#FAFAFA",
                transform=ax.transAxes,
            )
        )
        ax.text(x + 0.022, y + 0.058, num, fontsize=9, fontweight="bold", color="#4C72B0",
                ha="center", va="center", transform=ax.transAxes)
        ax.text(x + 0.045, y + 0.058, text, fontsize=5.9, ha="left", va="center",
                transform=ax.transAxes, linespacing=1.15)

    ax.add_patch(
        FancyBboxPatch(
            (0.03, 0.01), 0.94, 0.08,
            boxstyle="round,pad=0.010,rounding_size=0.014",
            linewidth=0.8, edgecolor="#C44E52", facecolor="#FFF6F5",
            transform=ax.transAxes,
        )
    )
    ax.text(0.05, 0.062, "Common failure modes: raw z-mean scores · no depth check · composite as “lactylation level”",
            fontsize=6.1, color="#7A1F1F", transform=ax.transAxes)
    ax.text(0.05, 0.032, "circular bridge axes · cell-level P values · no FDR · no protein validation",
            fontsize=6.1, color="#7A1F1F", transform=ax.transAxes)

    fig.savefig(os.path.join(OUT, "Figure6_week3_checklist.pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(OUT, "Figure6_week3_checklist.png"), bbox_inches="tight", dpi=400)
    plt.close(fig)


if __name__ == "__main__":
    fig1()
    fig6()
    print("saved to", OUT)
