"""Week 3: expression-matched random gene-set nulls for the residual L-M signal."""

from __future__ import annotations

import os
import time

import numpy as np
import pandas as pd
import scipy.io
import scipy.sparse as sp
from scipy import stats

ROOT = os.path.join(os.environ.get("OSLM_DATA_ROOT", "data"), "A2")
GENESETS = os.path.join(os.environ.get("OSLM_DATA_ROOT", "data"), "genesets")
W1 = os.path.join(os.environ.get("OSLM_WORK_ROOT", "work"), "week1")
OUT = os.path.join(os.environ.get("OSLM_WORK_ROOT", "work"), "week3")
os.makedirs(OUT, exist_ok=True)

SC = {
    "GSE152048_BC2": ("GSE152048", "BC2"),
    "GSE152048_BC3": ("GSE152048", "BC3"),
    "GSE162454_OS4": ("GSE162454", "OS_4"),
    "GSE318840_Treated1": ("GSE318840", "Treated1"),
    "GSE318840_Recurrent1": ("GSE318840", "Recurrent1"),
}
SP = {
    "PatientA": os.path.join(ROOT, "incoming", "GSE299025", "PatientA"),
    "PatientB": os.path.join(ROOT, "incoming", "GSE299025", "PatientB"),
}


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def load_matrix(sdir):
    feats = pd.read_csv(os.path.join(sdir, "features.tsv.gz"), sep="\t", header=None)
    bars = pd.read_csv(os.path.join(sdir, "barcodes.tsv.gz"), sep="\t", header=None)[0].astype(str).to_numpy()
    mat = sp.csr_matrix(scipy.io.mmread(os.path.join(sdir, "matrix.mtx.gz")))
    sym = feats[1].astype(str).to_numpy()
    uniq, inv = np.unique(sym, return_inverse=True)
    agg = sp.csr_matrix((np.ones(len(inv)), (inv, np.arange(len(inv)))), shape=(len(uniq), len(inv)))
    return (agg @ mat).tocsr(), uniq, bars


def lognorm(mat):
    x = mat.T.tocsr().astype(np.float32)
    lib = np.asarray(x.sum(axis=1)).ravel()
    lib[lib == 0] = 1
    x.data *= np.repeat(1e4 / lib, np.diff(x.indptr))
    x.data = np.log1p(x.data)
    return x


def residual_zmean(x, idx, n_genes):
    Y = x[:, idx].toarray().astype(float)
    X = np.column_stack([np.ones(len(n_genes)), n_genes, n_genes ** 2])
    beta, *_ = np.linalg.lstsq(X, Y, rcond=None)
    R = Y - X @ beta
    mu = R.mean(axis=0)
    sd = R.std(axis=0)
    sd[sd == 0] = 1
    return ((R - mu) / sd).mean(axis=1)


def main():
    lac = pd.read_csv(os.path.join(GENESETS, "lactylation_genes_v1.tsv"), sep="\t")
    mito = pd.read_csv(os.path.join(GENESETS, "mitophagy_genes_v1.tsv"), sep="\t")
    L = lac.loc[lac["include_primary"] == 1, "gene"].tolist()
    M = mito.loc[mito["include_primary_GO"] == 1, "gene"].tolist()
    program = set(L) | set(M)
    house = ("MT-", "RPL", "RPS", "MRPL", "MRPS")

    datasets = []
    for name, (series, subdir) in SC.items():
        meta = pd.read_csv(os.path.join(W1, f"percell_{name}.tsv.gz"), sep="\t")
        datasets.append(("sc_" + name, os.path.join(ROOT, "incoming", series, subdir), meta, "Malignant_Osteoblastic"))
    for name, sdir in SP.items():
        datasets.append(("sp_" + name, sdir, None, None))

    rows = []
    for label, sdir, meta, cell_type in datasets:
        log(f"loading {label}")
        mat, genes, bars = load_matrix(sdir)
        gi = {g: i for i, g in enumerate(genes)}
        if meta is not None:
            mm = meta.set_index("cell_id").reindex(bars)
            keep = (mm["cell_type"] == cell_type).to_numpy()
            mat = mat[:, keep]
            bars = bars[keep]
        x = lognorm(mat)
        n_genes = np.asarray((mat > 0).sum(axis=0)).ravel().astype(float)
        mean_expr = np.asarray(x.mean(axis=0)).ravel()
        det = np.asarray((x > 0).mean(axis=0)).ravel()

        # Expression/detection joint bins.
        eb = pd.qcut(pd.Series(mean_expr), 20, labels=False, duplicates="drop").to_numpy()
        db = pd.qcut(pd.Series(det), 20, labels=False, duplicates="drop").to_numpy()
        joint = eb.astype(str) + "_" + db.astype(str)
        members = {b: np.where(joint == b)[0] for b in np.unique(joint)}
        excluded = {
            i for i, g in enumerate(genes)
            if (g in program) or g.startswith(house) or g in {"MALAT1", "FTL", "FTH1", "B2M", "TMSB4X"}
        }
        bin_members_clean = {
            b: np.array([i for i in members[b] if i not in excluded], dtype=np.int32)
            for b in members
        }

        idxL = np.array([gi[g] for g in L if g in gi], dtype=np.int32)
        idxM = np.array([gi[g] for g in M if g in gi], dtype=np.int32)
        Lobs = residual_zmean(x, idxL, n_genes)
        Mobs = residual_zmean(x, idxM, n_genes)
        rho_obs = stats.spearmanr(Lobs, Mobs).statistic
        log(f"  observed L-M rho = {rho_obs:.3f}; L {len(idxL)} genes, M {len(idxM)} genes")

        def draw_set(size, seed):
            rng = np.random.default_rng(seed)
            out = []
            src = idxL if size == len(idxL) else idxM
            used = set()
            for gi0 in src:
                b = joint[gi0]
                cand = bin_members_clean.get(b, np.array([], dtype=np.int32))
                if len(cand) == 0:
                    continue
                for _ in range(10):
                    c = int(rng.choice(cand))
                    if c not in used:
                        used.add(c)
                        out.append(c)
                        break
            return np.array(out, dtype=np.int32)

        n_null = 1000
        null_L, null_M = [], []
        for i in range(n_null):
            rsetL = draw_set(len(idxL), 1000 + i)
            rsetM = draw_set(len(idxM), 2000 + i)
            rL = residual_zmean(x, rsetL, n_genes)
            rM = residual_zmean(x, rsetM, n_genes)
            null_L.append(stats.spearmanr(rL, Mobs).statistic)
            null_M.append(stats.spearmanr(Lobs, rM).statistic)

        null_L = np.array(null_L)
        null_M = np.array(null_M)
        for name, null in [("random_L_vs_M", null_L), ("L_vs_random_M", null_M)]:
            p = (1 + np.sum(null >= rho_obs)) / (1 + len(null))
            rows.append({
                "dataset": label,
                "test": name,
                "observed_rho": rho_obs,
                "null_mean": float(np.mean(null)),
                "null_q025": float(np.quantile(null, 0.025)),
                "null_q975": float(np.quantile(null, 0.975)),
                "empirical_p": float(p),
                "z": float((rho_obs - np.mean(null)) / (np.std(null) + 1e-9)),
                "n_cells_or_spots": len(bars),
            })
        log(f"  null L mean={null_L.mean():.3f} q975={np.quantile(null_L,0.975):.3f}; null M mean={null_M.mean():.3f} q975={np.quantile(null_M,0.975):.3f}")

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(OUT, "null_model_results.tsv"), sep="\t", index=False)
    print(out.to_string(index=False))


if __name__ == "__main__":
    main()
